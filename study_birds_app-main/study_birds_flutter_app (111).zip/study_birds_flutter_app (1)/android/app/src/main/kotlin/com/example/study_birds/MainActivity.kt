package com.example.study_birds

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
