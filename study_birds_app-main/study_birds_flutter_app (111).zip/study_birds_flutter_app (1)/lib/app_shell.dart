import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'screens/home_journey/home_dashboard_screen.dart';
import 'screens/home_journey/journey_tracker_screen.dart';
import 'screens/universities_programs_countries/explore_hub_screen.dart';
import 'screens/services_support/services_consultation_screens.dart';
import 'screens/profile_account/profile_account_screens.dart';

/// The connected student experience: one shared bottom nav, real navigation
/// between screens (tap a card → see the actual next screen), instead of
/// the flat screens-gallery list. This is what a client demo should run.
class StudentAppShell extends StatefulWidget {
  final StudentJourneyState journeyState;
  const StudentAppShell({super.key, this.journeyState = StudentJourneyState.applying});

  @override
  State<StudentAppShell> createState() => _StudentAppShellState();
}

class _StudentAppShellState extends State<StudentAppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final tabs = [
      HomeDashboardScreen(journeyState: widget.journeyState, embedInShell: true),
      const JourneyTrackerScreen(),
      const ExploreHubScreen(),
      const ServicesCenterScreen(),
      const ProfileScreen(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: _index, children: tabs),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _index,
          onTap: (i) => setState(() => _index = i),
          selectedItemColor: AppColors.navy,
          unselectedItemColor: AppColors.textSecondary,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
            BottomNavigationBarItem(icon: Icon(Icons.timeline_rounded), label: 'الرحلة'),
            BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), label: 'استكشاف'),
            BottomNavigationBarItem(icon: Icon(Icons.miscellaneous_services_outlined), label: 'الخدمات'),
            BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded), label: 'حسابي'),
          ],
        ),
      ),
    );
  }
}
