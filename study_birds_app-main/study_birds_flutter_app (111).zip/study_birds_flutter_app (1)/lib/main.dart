import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'app_shell.dart';

import 'screens/auth/splash_screen.dart';
import 'screens/auth/onboarding_and_account_type_screens.dart';
import 'screens/auth/login_register_screens.dart';
import 'screens/auth/otp_and_password_reset_screens.dart';
import 'screens/auth/student_registration_wizard_screen.dart';

import 'screens/home_journey/home_dashboard_screen.dart';
import 'screens/home_journey/journey_tracker_screen.dart';
import 'screens/home_journey/calendar_screen.dart';
import 'screens/home_journey/activity_log_screen.dart';
import 'screens/home_journey/notifications_screen.dart';
import 'screens/home_journey/important_dates_screen.dart';
import 'screens/home_journey/global_search_screen.dart';

import 'screens/auth/verify_contact_screen.dart';
import 'screens/profile_account/security_settings_screen.dart';

import 'screens/universities_programs_countries/compare_list_screen.dart';
import 'screens/services_support/messaging_and_emergency_screens.dart';

import 'screens/roles/agent_student_detail_screen.dart';
import 'screens/roles/university_application_review_screen.dart';
import 'screens/roles/employee_extra_screens.dart';

import 'screens/applications_documents_payments/applications_screens.dart';
import 'screens/applications_documents_payments/documents_screens.dart';
import 'screens/applications_documents_payments/payments_screens.dart';

import 'screens/universities_programs_countries/universities_screens.dart';
import 'screens/universities_programs_countries/programs_screens.dart';
import 'screens/universities_programs_countries/countries_scholarships_screens.dart';

import 'screens/visa_travel_accommodation/visa_travel_screens.dart';
import 'screens/visa_travel_accommodation/accommodation_arrival_screens.dart';

import 'screens/services_support/services_consultation_screens.dart';
import 'screens/services_support/support_team_ai_screens.dart';

import 'screens/profile_account/profile_account_screens.dart';

import 'screens/roles/parent_dashboard_screen.dart';
import 'screens/roles/agent_dashboard_screen.dart';
import 'screens/roles/university_dashboard_screen.dart';
import 'screens/roles/employee_dashboard_screen.dart';

void main() => runApp(const StudyBirdsApp());

class StudyBirdsApp extends StatelessWidget {
  const StudyBirdsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Study Birds',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.navy,
          primary: AppColors.navy,
          secondary: AppColors.orange,
          brightness: Brightness.light,
        ),
        fontFamily: 'Tajawal', // add Tajawal/Cairo to pubspec.yaml + assets for real Arabic typography
      ),
      home: const RootChooserScreen(),
    );
  }
}

/// First thing you see when running the app: choose between the full
/// connected demo (what a client should try) and the dev screens gallery
/// (for reviewing/QA-ing individual screens in isolation).
class RootChooserScreen extends StatelessWidget {
  const RootChooserScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/images/logo_mark.png', height: 64),
                  const SizedBox(height: 10),
                  const Text('Study Birds', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.navy)),
                  const SizedBox(height: 32),
                  PrimaryButton(
                    label: 'تجربة التطبيق كاملة (Prototype)',
                    icon: Icons.play_circle_fill_rounded,
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ConnectedPrototypeEntry())),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScreensGallery())),
                    icon: const Icon(Icons.grid_view_rounded, size: 18),
                    label: const Text('معرض الشاشات (للمراجعة الفردية)'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 48),
                      side: const BorderSide(color: AppColors.border),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Wires Splash → Onboarding → Account Type → Login/Register → the real
/// connected Student App Shell, using each screen's own callbacks so the
/// whole thing behaves like an actual app instead of isolated screens.
class ConnectedPrototypeEntry extends StatelessWidget {
  const ConnectedPrototypeEntry({super.key});

  @override
  Widget build(BuildContext context) {
    return SplashScreen(onFinished: () => _goOnboardingIntro(context));
  }

  static void _goOnboardingIntro(BuildContext context) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (ctx) => OnboardingIntroScreen(onDone: () => _goOnboardingServices(ctx)),
    ));
  }

  static void _goOnboardingServices(BuildContext context) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (ctx) => OnboardingServicesScreen(onContinue: () => _goAccountType(ctx)),
    ));
  }

  static void _goAccountType(BuildContext context) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (ctx) => AccountTypeSelectionScreen(onSelected: (type) => _goLogin(ctx)),
    ));
  }

  static void _goLogin(BuildContext context) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (ctx) => LoginScreen(
        onLogin: () => _goShell(ctx),
        onGoRegister: () => Navigator.of(ctx).push(MaterialPageRoute(
          builder: (ctx2) => RegisterScreen(onRegister: () => _goShell(ctx2)),
        )),
      ),
    ));
  }

  static void _goShell(BuildContext context) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const StudentAppShell()));
  }
}

/// A simple gallery so you (or a reviewer) can open any screen instantly
/// without wiring up full navigation/routing yet. Not part of the final app.
class ScreensGallery extends StatefulWidget {
  const ScreensGallery({super.key});

  @override
  State<ScreensGallery> createState() => _ScreensGalleryState();
}

class _ScreensGalleryState extends State<ScreensGallery> {
  String _query = '';

  static final Map<String, List<_GalleryEntry>> _sections = {
    'Auth': [
      _GalleryEntry('Splash', () => const SplashScreen()),
      _GalleryEntry('Onboarding Intro', () => OnboardingIntroScreen(onDone: () {})),
      _GalleryEntry('Onboarding Services', () => OnboardingServicesScreen(onContinue: () {})),
      _GalleryEntry('Account Type Selection', () => AccountTypeSelectionScreen(onSelected: (_) {})),
      _GalleryEntry('Login', () => const LoginScreen()),
      _GalleryEntry('Register (simple)', () => const RegisterScreen()),
      _GalleryEntry('Register (3-step wizard, per spec)', () => StudentRegistrationWizardScreen(onFinished: () {})),
      _GalleryEntry('OTP Verification', () => const OTPVerificationScreen()),
      _GalleryEntry('Verify Email', () => const VerifyContactScreen(isEmail: true)),
      _GalleryEntry('Verify Phone', () => const VerifyContactScreen(isEmail: false, contact: '+90 5XX XXX XX 12')),
      _GalleryEntry('Password Reset (2FA)', () => const PasswordReset2FAScreen()),
    ],
    'Home & Journey': [
      _GalleryEntry('Home — New Student', () => const HomeDashboardScreen(journeyState: StudentJourneyState.newStudent)),
      _GalleryEntry('Home — Applying', () => const HomeDashboardScreen(journeyState: StudentJourneyState.applying)),
      _GalleryEntry('Home — Admitted', () => const HomeDashboardScreen(journeyState: StudentJourneyState.admitted)),
      _GalleryEntry('Home — Traveling', () => const HomeDashboardScreen(journeyState: StudentJourneyState.traveling)),
      _GalleryEntry('Home — Arrived', () => const HomeDashboardScreen(journeyState: StudentJourneyState.arrived)),
      _GalleryEntry('Journey Tracker', () => const JourneyTrackerScreen()),
      _GalleryEntry('Calendar', () => const CalendarScreen()),
      _GalleryEntry('Activity Log', () => const ActivityLogScreen()),
      _GalleryEntry('Notifications', () => const NotificationsScreen()),
      _GalleryEntry('Important Dates', () => const ImportantDatesScreen()),
      _GalleryEntry('Global Search', () => const GlobalSearchScreen()),
    ],
    'Applications, Documents & Payments': [
      _GalleryEntry('Applications List', () => const ApplicationsListScreen()),
      _GalleryEntry('Applications List — Loading state', () => const ApplicationsListScreen(viewState: ScreenViewState.loading)),
      _GalleryEntry('Applications List — Error state', () => const ApplicationsListScreen(viewState: ScreenViewState.error)),
      _GalleryEntry('Applications List — Offline state', () => const ApplicationsListScreen(viewState: ScreenViewState.offline)),
      _GalleryEntry('Application Detail', () => const ApplicationDetailScreen()),
      _GalleryEntry('My Documents', () => const MyDocumentsScreen()),
      _GalleryEntry('Document Detail', () => const DocumentDetailScreen()),
      _GalleryEntry('Payments Summary', () => const PaymentsSummaryScreen()),
      _GalleryEntry('Payment Detail', () => const PaymentDetailScreen()),
      _GalleryEntry('Payment History', () => const PaymentHistoryScreen()),
    ],
    'Universities, Programs, Countries & Scholarships': [
      _GalleryEntry('Universities Explorer', () => const UniversitiesExplorerScreen()),
      _GalleryEntry('University Detail', () => const UniversityDetailScreen()),
      _GalleryEntry('Compare Universities', () => const CompareUniversitiesScreen()),
      _GalleryEntry('Programs Explorer', () => const ProgramsExplorerScreen()),
      _GalleryEntry('Program Detail', () => const ProgramDetailScreen()),
      _GalleryEntry('Program Finder', () => const ProgramFinderScreen()),
      _GalleryEntry('Program Finder Results', () => const ProgramFinderResultsScreen()),
      _GalleryEntry('Countries Explorer', () => const CountriesExplorerScreen()),
      _GalleryEntry('Country Detail', () => const CountryDetailScreen()),
      _GalleryEntry('Scholarships', () => const ScholarshipsScreen()),
      _GalleryEntry('Compare List (saved)', () => const CompareListScreen()),
    ],
    'Visa, Travel, Accommodation & After Arrival': [
      _GalleryEntry('Visa Center', () => const VisaCenterScreen()),
      _GalleryEntry('Visa Steps', () => const VisaStepsScreen()),
      _GalleryEntry('Travel Center', () => const TravelCenterScreen()),
      _GalleryEntry('Airport Pickup', () => const AirportPickupScreen()),
      _GalleryEntry('Accommodation', () => const AccommodationScreen()),
      _GalleryEntry('University Registration', () => const UniversityRegistrationScreen()),
      _GalleryEntry('Insurance', () => const InsuranceScreen()),
      _GalleryEntry('Equivalency', () => const EquivalencyScreen()),
    ],
    'Services, Support & Consultation': [
      _GalleryEntry('Services Center', () => const ServicesCenterScreen()),
      _GalleryEntry('Service Detail', () => const ServiceDetailScreen()),
      _GalleryEntry('Consultation Booking', () => const ConsultationBookingScreen()),
      _GalleryEntry('Consultation Confirmation', () => const ConsultationConfirmationScreen()),
      _GalleryEntry('Support Center', () => const SupportCenterScreen()),
      _GalleryEntry('New Support Ticket', () => const NewSupportTicketScreen()),
      _GalleryEntry('My Team', () => const MyTeamScreen()),
      _GalleryEntry('Bird AI Chat', () => const BirdAIChatScreen()),
      _GalleryEntry('Conversation Thread (In-App Messaging)', () => const ConversationThreadScreen()),
      _GalleryEntry('Emergency Support', () => const EmergencySupportScreen()),
    ],
    'Profile & Account': [
      _GalleryEntry('Profile', () => const ProfileScreen()),
      _GalleryEntry('Settings', () => const SettingsScreen()),
      _GalleryEntry('Security Settings (2FA/Sessions)', () => const SecuritySettingsScreen()),
      _GalleryEntry('Referral Program', () => const ReferralProgramScreen()),
      _GalleryEntry('My Wallet', () => const MyWalletScreen()),
      _GalleryEntry('Favorites', () => const FavoritesScreen()),
    ],
    'Other Account Types (Parent / Agent / University / Employee)': [
      _GalleryEntry('Parent Dashboard', () => const ParentDashboardScreen()),
      _GalleryEntry('Agent Dashboard', () => const AgentDashboardScreen()),
      _GalleryEntry('Agent — Student Detail', () => const AgentStudentDetailScreen()),
      _GalleryEntry('Agent — My Commissions', () => const MyCommissionsScreen()),
      _GalleryEntry('University Dashboard', () => const UniversityDashboardScreen()),
      _GalleryEntry('University — Application Review', () => const UniversityApplicationReviewScreen()),
      _GalleryEntry('Employee Dashboard', () => const EmployeeDashboardScreen()),
      _GalleryEntry('Employee — My Tasks', () => const MyTasksScreen()),
      _GalleryEntry('Employee — My Students Queue', () => const MyStudentsQueueScreen()),
      _GalleryEntry('Employee — Messages Inbox', () => const MessagesInboxScreen()),
      _GalleryEntry('Manager Overview', () => const ManagerOverviewScreen()),
    ],
  };

  @override
  Widget build(BuildContext context) {
    final filtered = <String, List<_GalleryEntry>>{};
    for (final entry in _sections.entries) {
      final matches = _query.isEmpty
          ? entry.value
          : entry.value.where((e) => e.title.toLowerCase().contains(_query.toLowerCase())).toList();
      if (matches.isNotEmpty) filtered[entry.key] = matches;
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        title: const Text('Study Birds — Screens Gallery', style: TextStyle(color: Colors.white, fontSize: 16)),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search screens...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              children: filtered.entries.expand((section) sync* {
                yield Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                  child: Text(section.key,
                      style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy, fontSize: 13)),
                );
                for (final e in section.value) {
                  yield ListTile(
                    title: Text(e.title),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => e.builder()),
                    ),
                  );
                }
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _GalleryEntry {
  final String title;
  final Widget Function() builder;
  const _GalleryEntry(this.title, this.builder);
}
