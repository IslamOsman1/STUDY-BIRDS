import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ApplicationSummary {
  final String university;
  final String program;
  final String country;
  final String status;
  final Color statusColor;
  final String nextAction;

  const ApplicationSummary({
    required this.university,
    required this.program,
    required this.country,
    required this.status,
    required this.statusColor,
    required this.nextAction,
  });
}

enum ScreenViewState { loading, error, offline, data }

class ApplicationsListScreen extends StatelessWidget {
  final ScreenViewState viewState;
  const ApplicationsListScreen({super.key, this.viewState = ScreenViewState.data});

  static const List<ApplicationSummary> _apps = [
    ApplicationSummary(
      university: 'جامعة إسطنبول التقنية',
      program: 'بكالوريوس العلاج الطبيعي',
      country: 'تركيا',
      status: 'قيد المراجعة من الجامعة',
      statusColor: AppColors.info,
      nextAction: 'بانتظار رد الجامعة',
    ),
    ApplicationSummary(
      university: 'جامعة بهتشة شهير',
      program: 'بكالوريوس إدارة الأعمال',
      country: 'تركيا',
      status: 'مطلوب مستندات إضافية',
      statusColor: AppColors.warning,
      nextAction: 'ارفع كشف الدرجات المصدق',
    ),
    ApplicationSummary(
      university: 'الجامعة الأمريكية بجورجيا',
      program: 'بكالوريوس علوم الحاسوب',
      country: 'جورجيا',
      status: 'قبول نهائي',
      statusColor: AppColors.success,
      nextAction: 'أكمل إجراءات الدفع',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'طلباتي',
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.add_circle_outline_rounded, color: Colors.white)),
      ],
      // Reference pattern: swap this switch for the real async/API state once
      // connected to a backend — every list screen should follow this same shape.
      body: Column(
        children: [
          if (viewState == ScreenViewState.offline) const OfflineBanner(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    switch (viewState) {
      case ScreenViewState.loading:
        return const LoadingState(message: 'جاري تحميل طلباتك...');
      case ScreenViewState.error:
        return ErrorState(message: 'تعذر تحميل طلباتك، تحقق من الاتصال وحاول مرة أخرى.', onRetry: () {});
      case ScreenViewState.offline:
      case ScreenViewState.data:
        if (_apps.isEmpty) {
          return const EmptyState(
            icon: Icons.description_outlined,
            title: 'لا توجد طلبات بعد',
            message: 'ابدأ رحلتك بتقديم طلبك الأول لجامعة تناسبك.',
            ctaLabel: 'استكشف الجامعات',
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _apps.length,
          itemBuilder: (context, i) {
            final a = _apps[i];
            return AppCard(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ApplicationDetailScreen())),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(a.university, style: AppTextStyles.cardTitle),
                      ),
                      StatusBadge(label: a.status, color: a.statusColor),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text('${a.program} — ${a.country}', style: AppTextStyles.caption),
                  const Divider(height: 20),
                  Row(
                    children: [
                      const Icon(Icons.arrow_left_rounded, size: 18, color: AppColors.orange),
                      Expanded(
                        child: Text(a.nextAction,
                            style: AppTextStyles.body.copyWith(color: AppColors.orange, fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
    }
  }
}

class ApplicationDetailScreen extends StatefulWidget {
  const ApplicationDetailScreen({super.key});

  @override
  State<ApplicationDetailScreen> createState() => _ApplicationDetailScreenState();
}

class _ApplicationDetailScreenState extends State<ApplicationDetailScreen> {
  int _tab = 0;
  static const _tabs = ['نظرة عامة', 'المستندات', 'الدفعات', 'القبول', 'الجدول الزمني', 'الرسائل'];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'تفاصيل الطلب',
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: AppCard(
              margin: EdgeInsets.zero,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: AppColors.navy.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.account_balance_rounded, color: AppColors.navy),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('جامعة إسطنبول التقنية', style: AppTextStyles.cardTitle),
                            Text('بكالوريوس العلاج الطبيعي', style: AppTextStyles.caption),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  Wrap(
                    spacing: 16,
                    runSpacing: 8,
                    children: const [
                      _InfoChip(label: 'الدولة', value: 'تركيا'),
                      _InfoChip(label: 'الحرم الجامعي', value: 'الرئيسي'),
                      _InfoChip(label: 'الدرجة', value: 'بكالوريوس'),
                      _InfoChip(label: 'اللغة', value: 'الإنجليزية'),
                      _InfoChip(label: 'الفصل', value: 'خريف 2026'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _tabs.length,
              itemBuilder: (context, i) {
                final selected = i == _tab;
                return GestureDetector(
                  onTap: () => setState(() => _tab = i),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? AppColors.navy : Colors.white,
                      borderRadius: BorderRadius.circular(AppRadius.chip),
                      border: Border.all(color: selected ? AppColors.navy : AppColors.border),
                    ),
                    child: Text(
                      _tabs[i],
                      style: TextStyle(
                        color: selected ? Colors.white : AppColors.textPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 12.5,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: const [
                        StatusBadge(label: 'قيد المراجعة من الجامعة', color: AppColors.info),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text('الخطوة القادمة', style: AppTextStyles.sectionLabel),
                    const SizedBox(height: 6),
                    const Text('طلبك حاليًا قيد المراجعة من قبل الجامعة، سيتم إعلامك فور توفر أي تحديث.',
                        style: AppTextStyles.body),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final String label;
  final String value;
  const _InfoChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.caption),
        Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700)),
      ],
    );
  }
}
