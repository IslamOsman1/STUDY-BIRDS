import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class DocumentItem {
  final String name;
  final String status;
  final Color statusColor;
  final IconData icon;

  const DocumentItem({
    required this.name,
    required this.status,
    required this.statusColor,
    this.icon = Icons.insert_drive_file_outlined,
  });
}

class MyDocumentsScreen extends StatelessWidget {
  const MyDocumentsScreen({super.key});

  static const List<DocumentItem> _docs = [
    DocumentItem(name: 'جواز السفر', status: 'تمت الموافقة', statusColor: AppColors.success),
    DocumentItem(name: 'كشف الدرجات', status: 'قيد المراجعة', statusColor: AppColors.info),
    DocumentItem(name: 'شهادة الثانوية العامة', status: 'مرفوض', statusColor: AppColors.danger),
    DocumentItem(name: 'صورة شخصية', status: 'مطلوب ترجمة', statusColor: AppColors.warning),
    DocumentItem(name: 'شهادة اللغة الإنجليزية', status: 'مفقود', statusColor: AppColors.neutral),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مستنداتي',
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _docs.length,
        itemBuilder: (context, i) {
          final d = _docs[i];
          return AppCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DocumentDetailScreen())),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.navy.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(d.icon, color: AppColors.navy, size: 19),
                ),
                const SizedBox(width: 12),
                Expanded(child: Text(d.name, style: AppTextStyles.cardTitle)),
                StatusBadge(label: d.status, color: d.statusColor),
              ],
            ),
          );
        },
      ),
    );
  }
}

class DocumentDetailScreen extends StatelessWidget {
  final bool rejected;
  const DocumentDetailScreen({super.key, this.rejected = true});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'شهادة الثانوية العامة',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 180,
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.navy.withOpacity(0.05),
                borderRadius: BorderRadius.circular(AppRadius.card),
                border: Border.all(color: AppColors.border),
              ),
              child: const Center(
                child: Icon(Icons.description_outlined, size: 48, color: AppColors.textSecondary),
              ),
            ),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('تاريخ الرفع', style: AppTextStyles.caption),
                      Text('10 سبتمبر 2026', style: AppTextStyles.body),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('الحالة', style: AppTextStyles.caption),
                      StatusBadge(label: 'مرفوض', color: AppColors.danger),
                    ],
                  ),
                ],
              ),
            ),
            if (rejected) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.danger.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(AppRadius.card),
                  border: Border.all(color: AppColors.danger.withOpacity(0.3)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Icon(Icons.info_outline_rounded, color: AppColors.danger, size: 20),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'هذا المستند غير واضح، الرجاء رفع نسخة أوضح.',
                        style: TextStyle(color: AppColors.danger, fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 20),
            PrimaryButton(label: 'رفع نسخة جديدة', onPressed: () {}, icon: Icons.upload_file_rounded),
          ],
        ),
      ),
    );
  }
}
