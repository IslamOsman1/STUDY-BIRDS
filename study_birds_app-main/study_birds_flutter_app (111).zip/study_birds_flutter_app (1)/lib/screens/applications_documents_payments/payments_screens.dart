import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class InvoiceItem {
  final String description;
  final String amount;
  final String dueDate;
  final String status;
  final Color statusColor;

  const InvoiceItem({
    required this.description,
    required this.amount,
    required this.dueDate,
    required this.status,
    required this.statusColor,
  });
}

class PaymentsSummaryScreen extends StatelessWidget {
  const PaymentsSummaryScreen({super.key});

  static const List<InvoiceItem> _invoices = [
    InvoiceItem(description: 'دفعة القبول الأولى', amount: '500\$', dueDate: '24 سبتمبر 2026', status: 'مستحقة', statusColor: AppColors.warning),
    InvoiceItem(description: 'رسوم خدمة الترجمة', amount: '40\$', dueDate: '2 سبتمبر 2026', status: 'مدفوعة', statusColor: AppColors.success),
    InvoiceItem(description: 'رسوم التقديم', amount: '75\$', dueDate: '20 أغسطس 2026', status: 'مدفوعة', statusColor: AppColors.success),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'ملخص الدفعات',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    _SummaryStat(label: 'الإجمالي', value: '615\$'),
                    _SummaryStat(label: 'المدفوع', value: '115\$', color: AppColors.success),
                    _SummaryStat(label: 'المتبقي', value: '500\$', color: AppColors.warning),
                  ],
                ),
                const Divider(height: 28),
                Row(
                  children: const [
                    Icon(Icons.event_rounded, size: 18, color: AppColors.orange),
                    SizedBox(width: 8),
                    Text('الدفعة القادمة: 24 سبتمبر 2026', style: AppTextStyles.body),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          const Text('الفواتير', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          ..._invoices.map(
            (inv) => AppCard(
              onTap: () {},
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(inv.description, style: AppTextStyles.cardTitle),
                        const SizedBox(height: 3),
                        Text(inv.dueDate, style: AppTextStyles.caption),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(inv.amount, style: AppTextStyles.cardTitle),
                      const SizedBox(height: 4),
                      StatusBadge(label: inv.status, color: inv.statusColor),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryStat extends StatelessWidget {
  final String label;
  final String value;
  final Color? color;
  const _SummaryStat({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: AppTextStyles.screenTitle.copyWith(color: color ?? AppColors.navy, fontSize: 17)),
        const SizedBox(height: 2),
        Text(label, style: AppTextStyles.caption),
      ],
    );
  }
}

class PaymentDetailScreen extends StatelessWidget {
  const PaymentDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'تفاصيل الدفعة',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Text('500\$', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: AppColors.navy)),
            ),
            const SizedBox(height: 20),
            AppCard(
              child: Column(
                children: const [
                  _DetailRow(label: 'الوصف', value: 'دفعة القبول الأولى'),
                  Divider(height: 20),
                  _DetailRow(label: 'تاريخ الاستحقاق', value: '24 سبتمبر 2026'),
                  Divider(height: 20),
                  _DetailRow(label: 'الطلب المرتبط', value: 'جامعة إسطنبول التقنية'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            PrimaryButton(label: 'رفع إيصال الدفع', onPressed: () {}, icon: Icons.upload_file_rounded),
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.caption),
        Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class PaymentHistoryScreen extends StatelessWidget {
  const PaymentHistoryScreen({super.key});

  static const List<InvoiceItem> _history = [
    InvoiceItem(description: 'رسوم خدمة الترجمة', amount: '40\$', dueDate: '2 سبتمبر 2026', status: 'موثقة', statusColor: AppColors.success),
    InvoiceItem(description: 'رسوم التقديم', amount: '75\$', dueDate: '20 أغسطس 2026', status: 'موثقة', statusColor: AppColors.success),
    InvoiceItem(description: 'دفعة استشارة', amount: '20\$', dueDate: '5 أغسطس 2026', status: 'مرفوضة', statusColor: AppColors.danger),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'سجل الدفعات',
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _history.length,
        itemBuilder: (context, i) {
          final h = _history[i];
          return AppCard(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(h.description, style: AppTextStyles.cardTitle),
                      const SizedBox(height: 3),
                      Text(h.dueDate, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(h.amount, style: AppTextStyles.cardTitle),
                    const SizedBox(height: 4),
                    StatusBadge(label: h.status, color: h.statusColor),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
