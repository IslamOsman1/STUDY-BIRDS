import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class _AppTextField extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool obscure;
  final TextInputType? keyboardType;

  const _AppTextField({
    required this.label,
    required this.icon,
    this.obscure = false,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.caption),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadius.button),
            border: Border.all(color: AppColors.border),
          ),
          child: TextField(
            obscureText: obscure,
            keyboardType: keyboardType,
            textAlign: TextAlign.right,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
              prefixIcon: Icon(icon, color: AppColors.navy, size: 20),
            ),
          ),
        ),
      ],
    );
  }
}

class LoginScreen extends StatelessWidget {
  final VoidCallback? onLogin;
  final VoidCallback? onGoRegister;
  final VoidCallback? onForgotPassword;

  const LoginScreen({super.key, this.onLogin, this.onGoRegister, this.onForgotPassword});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                const Text('أهلاً بعودتك 👋', style: AppTextStyles.screenTitle),
                const SizedBox(height: 6),
                const Text('سجّل دخولك لمتابعة رحلتك الدراسية', style: AppTextStyles.caption),
                const SizedBox(height: 28),
                const _AppTextField(label: 'البريد الإلكتروني أو رقم الهاتف', icon: Icons.person_outline_rounded),
                const SizedBox(height: 14),
                const _AppTextField(label: 'كلمة المرور', icon: Icons.lock_outline_rounded, obscure: true),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: onForgotPassword,
                    child: const Text('نسيت كلمة المرور؟', style: TextStyle(color: AppColors.orange)),
                  ),
                ),
                const SizedBox(height: 8),
                PrimaryButton(label: 'تسجيل الدخول', onPressed: onLogin),
                const SizedBox(height: 16),
                Row(
                  children: const [
                    Expanded(child: Divider()),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: Text('أو', style: AppTextStyles.caption),
                    ),
                    Expanded(child: Divider()),
                  ],
                ),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.g_mobiledata_rounded, size: 24),
                  label: const Text('المتابعة عبر جوجل'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 48),
                    side: const BorderSide(color: AppColors.border),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadius.button),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.apple_rounded, size: 20),
                  label: const Text('المتابعة عبر Apple'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 48),
                    side: const BorderSide(color: AppColors.border),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadius.button),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Center(
                  child: TextButton(
                    onPressed: onGoRegister,
                    child: RichText(
                      text: const TextSpan(
                        style: AppTextStyles.body,
                        children: [
                          TextSpan(text: 'ليس لديك حساب؟ '),
                          TextSpan(
                            text: 'إنشاء حساب جديد',
                            style: TextStyle(color: AppColors.orange, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterScreen extends StatelessWidget {
  final VoidCallback? onRegister;
  final VoidCallback? onGoLogin;

  const RegisterScreen({super.key, this.onRegister, this.onGoLogin});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'إنشاء حساب',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('لنبدأ رحلتك 🎓', style: AppTextStyles.screenTitle),
            const SizedBox(height: 6),
            const Text('التسجيل بسيط، وتقدر تكمل باقي بياناتك لاحقًا من ملفك الشخصي',
                style: AppTextStyles.caption),
            const SizedBox(height: 24),
            const _AppTextField(label: 'الاسم الكامل', icon: Icons.badge_outlined),
            const SizedBox(height: 14),
            const _AppTextField(
              label: 'البريد الإلكتروني',
              icon: Icons.email_outlined,
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 14),
            const _AppTextField(
              label: 'رقم الهاتف',
              icon: Icons.phone_outlined,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 14),
            const _AppTextField(label: 'كلمة المرور', icon: Icons.lock_outline_rounded, obscure: true),
            const SizedBox(height: 20),
            PrimaryButton(label: 'إنشاء الحساب', onPressed: onRegister),
            const SizedBox(height: 16),
            Center(
              child: TextButton(
                onPressed: onGoLogin,
                child: RichText(
                  text: const TextSpan(
                    style: AppTextStyles.body,
                    children: [
                      TextSpan(text: 'لديك حساب بالفعل؟ '),
                      TextSpan(
                        text: 'تسجيل الدخول',
                        style: TextStyle(color: AppColors.orange, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
