import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class OTPVerificationScreen extends StatelessWidget {
  final String destination;
  final VoidCallback? onVerify;
  final VoidCallback? onResend;

  const OTPVerificationScreen({
    super.key,
    this.destination = '+90 5XX XXX XX 12',
    this.onVerify,
    this.onResend,
  });

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'رمز التحقق',
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('تحقق من رقمك', style: AppTextStyles.screenTitle),
            const SizedBox(height: 8),
            Text('أرسلنا رمز مكوّن من 6 أرقام إلى $destination',
                style: AppTextStyles.caption),
            const SizedBox(height: 28),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(
                6,
                (i) => Container(
                  width: 44,
                  height: 52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: i == 0 ? AppColors.orange : AppColors.border,
                      width: i == 0 ? 1.6 : 1,
                    ),
                  ),
                  child: const Text('', style: AppTextStyles.screenTitle),
                ),
              ),
            ),
            const SizedBox(height: 24),
            PrimaryButton(label: 'تأكيد', onPressed: onVerify),
            const SizedBox(height: 16),
            Center(
              child: TextButton(
                onPressed: onResend,
                child: RichText(
                  text: const TextSpan(
                    style: AppTextStyles.body,
                    children: [
                      TextSpan(text: 'لم يصلك الرمز؟ '),
                      TextSpan(
                        text: 'إعادة الإرسال',
                        style: TextStyle(color: AppColors.orange, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

enum ResetStage { requestEmail, otpAnd2fa, newPassword, success }

class PasswordReset2FAScreen extends StatefulWidget {
  const PasswordReset2FAScreen({super.key});

  @override
  State<PasswordReset2FAScreen> createState() => _PasswordReset2FAScreenState();
}

class _PasswordReset2FAScreenState extends State<PasswordReset2FAScreen> {
  ResetStage _stage = ResetStage.requestEmail;

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'إعادة تعيين كلمة المرور',
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: _buildStage(),
      ),
    );
  }

  Widget _buildStage() {
    switch (_stage) {
      case ResetStage.requestEmail:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('أدخل بريدك الإلكتروني', style: AppTextStyles.screenTitle),
            const SizedBox(height: 8),
            const Text('سنرسل لك رمز تحقق لإعادة تعيين كلمة المرور', style: AppTextStyles.caption),
            const SizedBox(height: 24),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.button),
                border: Border.all(color: AppColors.border),
              ),
              child: const TextField(
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  prefixIcon: Icon(Icons.email_outlined, color: AppColors.navy),
                  hintText: 'example@email.com',
                ),
              ),
            ),
            const SizedBox(height: 20),
            PrimaryButton(
              label: 'إرسال الرمز',
              onPressed: () => setState(() => _stage = ResetStage.otpAnd2fa),
            ),
          ],
        );
      case ResetStage.otpAnd2fa:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('التحقق بخطوتين', style: AppTextStyles.screenTitle),
            const SizedBox(height: 8),
            const Text('أدخل رمز التحقق المرسل إلى بريدك وجهازك الموثوق',
                style: AppTextStyles.caption),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(
                6,
                (i) => Container(
                  width: 44,
                  height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            PrimaryButton(
              label: 'تأكيد',
              onPressed: () => setState(() => _stage = ResetStage.newPassword),
            ),
          ],
        );
      case ResetStage.newPassword:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('كلمة مرور جديدة', style: AppTextStyles.screenTitle),
            const SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.button),
                border: Border.all(color: AppColors.border),
              ),
              child: const TextField(
                obscureText: true,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  prefixIcon: Icon(Icons.lock_outline_rounded, color: AppColors.navy),
                  hintText: 'كلمة المرور الجديدة',
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.button),
                border: Border.all(color: AppColors.border),
              ),
              child: const TextField(
                obscureText: true,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  prefixIcon: Icon(Icons.lock_outline_rounded, color: AppColors.navy),
                  hintText: 'تأكيد كلمة المرور',
                ),
              ),
            ),
            const SizedBox(height: 20),
            PrimaryButton(
              label: 'حفظ كلمة المرور',
              onPressed: () => setState(() => _stage = ResetStage.success),
            ),
          ],
        );
      case ResetStage.success:
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.check_rounded, color: AppColors.success, size: 42),
              ),
              const SizedBox(height: 20),
              const Text('تم تغيير كلمة المرور بنجاح', style: AppTextStyles.cardTitle),
              const SizedBox(height: 6),
              const Text('يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة',
                  style: AppTextStyles.caption, textAlign: TextAlign.center),
              const SizedBox(height: 24),
              PrimaryButton(label: 'تسجيل الدخول', onPressed: () {}, expand: false),
            ],
          ),
        );
    }
  }
}
