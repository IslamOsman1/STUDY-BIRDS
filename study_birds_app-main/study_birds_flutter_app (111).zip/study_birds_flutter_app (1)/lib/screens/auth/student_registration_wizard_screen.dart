import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// 3-step Student Registration wizard.
/// Step 1: Basic Info — Step 2: Academic Info — Step 3: Study Abroad Preferences.
/// Per spec: collect the minimum required now; the rest can be completed later in Profile.
class StudentRegistrationWizardScreen extends StatefulWidget {
  final VoidCallback? onFinished;
  const StudentRegistrationWizardScreen({super.key, this.onFinished});

  @override
  State<StudentRegistrationWizardScreen> createState() => _StudentRegistrationWizardScreenState();
}

class _StudentRegistrationWizardScreenState extends State<StudentRegistrationWizardScreen> {
  int _step = 0;
  static const int _totalSteps = 3;
  static const List<String> _stepTitles = ['البيانات الأساسية', 'المعلومات الأكاديمية', 'تفضيلات الدراسة بالخارج'];

  void _next() {
    if (_step < _totalSteps - 1) {
      setState(() => _step++);
    } else {
      widget.onFinished?.call();
    }
  }

  void _back() {
    if (_step > 0) {
      setState(() => _step--);
    } else {
      Navigator.of(context).maybePop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: AppColors.navy,
          elevation: 0,
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded, color: Colors.white), onPressed: _back),
          title: Text(_stepTitles[_step], style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          centerTitle: true,
          actions: [
            if (_step < _totalSteps - 1)
              TextButton(
                onPressed: widget.onFinished, // allow finishing later, per spec: don't force all data now
                child: const Text('إكمال لاحقًا', style: TextStyle(color: Colors.white70, fontSize: 12.5)),
              ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Row(
                  children: List.generate(_totalSteps, (i) {
                    final active = i <= _step;
                    return Expanded(
                      child: Container(
                        height: 5,
                        margin: EdgeInsets.only(left: i == _totalSteps - 1 ? 0 : 6),
                        decoration: BoxDecoration(
                          color: active ? AppColors.orange : AppColors.border,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: _buildStepContent(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: PrimaryButton(
                  label: _step == _totalSteps - 1 ? 'إنشاء الحساب' : 'التالي',
                  onPressed: _next,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_step) {
      case 0:
        return const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Field(label: 'الاسم الكامل (بالإنجليزية)'),
            _Field(label: 'الاسم بالعربية'),
            _Field(label: 'تاريخ الميلاد', icon: Icons.calendar_today_outlined),
            _Field(label: 'الجنس', isDropdown: true, options: ['ذكر', 'أنثى']),
            _Field(label: 'الجنسية'),
            _Field(label: 'دولة الإقامة الحالية'),
            _Field(label: 'رقم الهاتف', icon: Icons.phone_outlined),
            _Field(label: 'البريد الإلكتروني', icon: Icons.email_outlined),
            _Field(label: 'اللغة المفضلة', isDropdown: true, options: ['العربية', 'الإنجليزية']),
          ],
        );
      case 1:
        return const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Field(label: 'المرحلة التعليمية الحالية', isDropdown: true, options: ['الثانوية العامة', 'بكالوريوس', 'ماجستير']),
            _Field(label: 'اسم المدرسة / الجامعة الحالية'),
            _Field(label: 'المعدل / GPA'),
            _Field(label: 'سنة التخرج المتوقعة'),
            _Field(label: 'التخصص (إن وجد)'),
          ],
        );
      case 2:
      default:
        return const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Field(label: 'الدول المفضلة للدراسة', isMultiChip: true, options: ['تركيا', 'جورجيا', 'ماليزيا', 'أوزبكستان']),
            _Field(label: 'المدن المفضلة'),
            _Field(label: 'البرامج المفضلة'),
            _Field(label: 'الدرجة العلمية المفضلة', isDropdown: true, options: ['بكالوريوس', 'ماجستير', 'دكتوراه']),
            _Field(label: 'لغة الدراسة المفضلة', isDropdown: true, options: ['الإنجليزية', 'التركية']),
            _Field(label: 'الميزانية التقريبية'),
            _Field(label: 'الفصل الدراسي (Intake)', isDropdown: true, options: ['خريف 2026', 'ربيع 2027']),
            _Field(label: 'الرغبة في الحصول على منحة', isDropdown: true, options: ['نعم', 'لا', 'غير متأكد']),
          ],
        );
    }
  }
}

class _Field extends StatefulWidget {
  final String label;
  final IconData? icon;
  final bool isDropdown;
  final bool isMultiChip;
  final List<String>? options;

  const _Field({required this.label, this.icon, this.isDropdown = false, this.isMultiChip = false, this.options});

  @override
  State<_Field> createState() => _FieldState();
}

class _FieldState extends State<_Field> {
  final Set<String> _selectedChips = {};

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.label, style: AppTextStyles.caption),
          const SizedBox(height: 6),
          if (widget.isMultiChip)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: (widget.options ?? []).map((o) {
                final selected = _selectedChips.contains(o);
                return GestureDetector(
                  onTap: () => setState(() => selected ? _selectedChips.remove(o) : _selectedChips.add(o)),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected ? AppColors.orange.withOpacity(0.12) : Colors.white,
                      borderRadius: BorderRadius.circular(AppRadius.chip),
                      border: Border.all(color: selected ? AppColors.orange : AppColors.border),
                    ),
                    child: Text(o, style: TextStyle(color: selected ? AppColors.orange : AppColors.textPrimary, fontSize: 12.5, fontWeight: FontWeight.w600)),
                  ),
                );
              }).toList(),
            )
          else if (widget.isDropdown)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.button), border: Border.all(color: AppColors.border)),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  isExpanded: true,
                  hint: Text('اختر', style: AppTextStyles.body.copyWith(color: AppColors.textSecondary)),
                  items: (widget.options ?? []).map((o) => DropdownMenuItem(value: o, child: Text(o))).toList(),
                  onChanged: (_) {},
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.button), border: Border.all(color: AppColors.border)),
              child: TextField(
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                  prefixIcon: widget.icon != null ? Icon(widget.icon, color: AppColors.navy, size: 19) : null,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
