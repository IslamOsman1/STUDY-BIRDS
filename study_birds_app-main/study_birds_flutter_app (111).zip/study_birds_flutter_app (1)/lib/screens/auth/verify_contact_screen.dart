import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// Separate from login OTP — this is the standalone Verify Email/Phone
/// flow reachable from Settings/Security (spec point 6 and 72).
class VerifyContactScreen extends StatelessWidget {
  final bool isEmail; // true = verify email, false = verify phone
  final String contact;
  final VoidCallback? onVerify;

  const VerifyContactScreen({super.key, this.isEmail = true, this.contact = 'ahmad@email.com', this.onVerify});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: isEmail ? 'تأكيد البريد الإلكتروني' : 'تأكيد رقم الهاتف',
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(color: AppColors.navy.withOpacity(0.08), shape: BoxShape.circle),
              child: Icon(isEmail ? Icons.mark_email_read_outlined : Icons.phone_android_rounded, color: AppColors.navy, size: 30),
            ),
            const SizedBox(height: 16),
            Text(isEmail ? 'تأكد من بريدك الإلكتروني' : 'تأكد من رقم هاتفك', style: AppTextStyles.screenTitle),
            const SizedBox(height: 8),
            Text('أرسلنا رمز تحقق مكوّن من 6 أرقام إلى $contact', style: AppTextStyles.caption),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(
                6,
                (i) => Container(
                  width: 44,
                  height: 52,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: i == 0 ? AppColors.orange : AppColors.border, width: i == 0 ? 1.6 : 1)),
                ),
              ),
            ),
            const SizedBox(height: 24),
            PrimaryButton(label: 'تأكيد', onPressed: onVerify),
            const SizedBox(height: 12),
            Center(
              child: TextButton(
                onPressed: () {},
                child: const Text('إعادة إرسال الرمز', style: TextStyle(color: AppColors.orange, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
