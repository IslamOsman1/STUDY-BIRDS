import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ActivityLogEvent {
  final String date;
  final String description;
  final IconData icon;
  final Color color;

  const ActivityLogEvent({
    required this.date,
    required this.description,
    required this.icon,
    this.color = AppColors.info,
  });
}

class ActivityLogScreen extends StatelessWidget {
  const ActivityLogScreen({super.key});

  // Mock data — replace with real feed from backend.
  static const List<ActivityLogEvent> _events = [
    ActivityLogEvent(
      date: '12 سبتمبر',
      description: 'تمت الموافقة على المستند من قبل فريق القبول',
      icon: Icons.verified_rounded,
      color: AppColors.success,
    ),
    ActivityLogEvent(
      date: '11 سبتمبر',
      description: 'تم رفع جواز السفر',
      icon: Icons.upload_file_rounded,
      color: AppColors.info,
    ),
    ActivityLogEvent(
      date: '9 سبتمبر',
      description: 'تم تأكيد موعد المقابلة الخاصة بالتأشيرة',
      icon: Icons.event_available_rounded,
      color: AppColors.orange,
    ),
    ActivityLogEvent(
      date: '6 سبتمبر',
      description: 'تم استلام الدفعة الأولى من الرسوم الدراسية',
      icon: Icons.payments_rounded,
      color: AppColors.success,
    ),
    ActivityLogEvent(
      date: '2 سبتمبر',
      description: 'تم تقديم الطلب إلى جامعة إسطنبول التقنية',
      icon: Icons.send_rounded,
      color: AppColors.info,
    ),
    ActivityLogEvent(
      date: '28 أغسطس',
      description: 'تم إنشاء حسابك في Study Birds',
      icon: Icons.flag_rounded,
      color: AppColors.neutral,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'سجل الأنشطة',
      body: _events.isEmpty
          ? const EmptyState(
              icon: Icons.history_rounded,
              title: 'لا يوجد نشاط بعد',
              message: 'ستظهر هنا كل الأحداث المتعلقة برحلتك الدراسية أولاً بأول.',
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              itemCount: _events.length,
              itemBuilder: (context, index) {
                final event = _events[index];
                final isLast = index == _events.length - 1;
                return _TimelineRow(event: event, isLast: isLast);
              },
            ),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  final ActivityLogEvent event;
  final bool isLast;

  const _TimelineRow({required this.event, required this.isLast});

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: event.color.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(event.icon, size: 17, color: event.color),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    color: AppColors.border,
                  ),
                ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 20, top: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(event.date, style: AppTextStyles.caption),
                  const SizedBox(height: 3),
                  Text(event.description, style: AppTextStyles.body),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
