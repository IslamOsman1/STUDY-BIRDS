import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class CalendarEvent {
  final String title;
  final String time;
  final IconData icon;
  final Color color;
  const CalendarEvent({required this.title, required this.time, required this.icon, required this.color});
}

/// Calendar linking journey-related events — spec point 99: consultation,
/// payment deadlines, visa appointments, travel, university registration.
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  int _selectedDay = 19;

  static const Map<int, List<CalendarEvent>> _eventsByDay = {
    18: [CalendarEvent(title: 'استشارة أونلاين مع سارة أحمد', time: '11:00 ص', icon: Icons.support_agent_rounded, color: AppColors.info)],
    19: [CalendarEvent(title: 'موعد مقابلة التأشيرة', time: '10:00 ص', icon: Icons.flight_takeoff_rounded, color: AppColors.danger)],
    24: [CalendarEvent(title: 'موعد استحقاق الدفعة الثانية', time: 'طوال اليوم', icon: Icons.payments_rounded, color: AppColors.warning)],
    30: [CalendarEvent(title: 'الموعد النهائي لتقديم الطلب', time: 'طوال اليوم', icon: Icons.edit_document, color: AppColors.warning)],
  };

  @override
  Widget build(BuildContext context) {
    final daysWithEvents = _eventsByDay.keys.toSet();
    final events = _eventsByDay[_selectedDay] ?? [];

    return AppScaffold(
      title: 'التقويم',
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Align(alignment: Alignment.centerRight, child: Text('سبتمبر 2026', style: AppTextStyles.sectionLabel)),
                const SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: 30,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 6, crossAxisSpacing: 6),
                  itemBuilder: (context, i) {
                    final day = i + 1;
                    final hasEvent = daysWithEvents.contains(day);
                    final selected = day == _selectedDay;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedDay = day),
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: selected ? AppColors.navy : Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: selected ? AppColors.navy : AppColors.border),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('$day', style: TextStyle(color: selected ? Colors.white : AppColors.textPrimary, fontSize: 12, fontWeight: FontWeight.w600)),
                            if (hasEvent)
                              Container(
                                margin: const EdgeInsets.only(top: 2),
                                width: 4,
                                height: 4,
                                decoration: BoxDecoration(color: selected ? Colors.white : AppColors.orange, shape: BoxShape.circle),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: events.isEmpty
                ? const EmptyState(icon: Icons.event_available_outlined, title: 'لا يوجد أحداث', message: 'مفيش مواعيد مسجلة في اليوم ده.')
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: events.length,
                    itemBuilder: (context, i) {
                      final e = events[i];
                      return AppCard(
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(color: e.color.withOpacity(0.12), borderRadius: BorderRadius.circular(9)),
                              child: Icon(e.icon, color: e.color, size: 17),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(e.title, style: AppTextStyles.cardTitle),
                                  Text(e.time, style: AppTextStyles.caption),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
