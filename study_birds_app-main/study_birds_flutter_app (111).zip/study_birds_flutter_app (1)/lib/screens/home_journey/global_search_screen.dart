import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class SearchResultItem {
  final String title;
  final String subtitle;
  final IconData icon;

  const SearchResultItem(
      {required this.title, required this.subtitle, required this.icon});
}

class SearchResultSection {
  final String label;
  final List<SearchResultItem> items;

  const SearchResultSection({required this.label, required this.items});
}

class GlobalSearchScreen extends StatefulWidget {
  const GlobalSearchScreen({super.key});

  @override
  State<GlobalSearchScreen> createState() => _GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends State<GlobalSearchScreen> {
  final TextEditingController _controller = TextEditingController();

  // Mock grouped results — replace with live search-as-you-type from backend.
  static const List<SearchResultSection> _sections = [
    SearchResultSection(label: 'الجامعات', items: [
      SearchResultItem(
        title: 'جامعة إسطنبول التقنية',
        subtitle: 'إسطنبول، تركيا',
        icon: Icons.account_balance_rounded,
      ),
      SearchResultItem(
        title: 'جامعة بهتشة شهير',
        subtitle: 'إسطنبول، تركيا',
        icon: Icons.account_balance_rounded,
      ),
    ]),
    SearchResultSection(label: 'البرامج', items: [
      SearchResultItem(
        title: 'بكالوريوس العلاج الطبيعي',
        subtitle: '4 سنوات - الإنجليزية',
        icon: Icons.menu_book_rounded,
      ),
    ]),
    SearchResultSection(label: 'الدول', items: [
      SearchResultItem(
        title: 'تركيا',
        subtitle: '+180 جامعة متاحة',
        icon: Icons.public_rounded,
      ),
    ]),
    SearchResultSection(label: 'المقالات', items: [
      SearchResultItem(
        title: 'دليلك الكامل للدراسة في تركيا 2026',
        subtitle: 'قراءة 6 دقائق',
        icon: Icons.article_rounded,
      ),
    ]),
    SearchResultSection(label: 'الأسئلة الشائعة', items: [
      SearchResultItem(
        title: 'كيف أحصل على تأشيرة الطالب؟',
        subtitle: 'مركز المساعدة',
        icon: Icons.help_outline_rounded,
      ),
    ]),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'البحث',
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.card),
                border: Border.all(color: AppColors.border),
              ),
              child: TextField(
                controller: _controller,
                textAlign: TextAlign.right,
                decoration: const InputDecoration(
                  hintText: 'ابحث عن جامعة، برنامج، دولة...',
                  hintStyle: TextStyle(color: AppColors.textSecondary, fontSize: 13.5),
                  prefixIcon: Icon(Icons.search_rounded, color: AppColors.navy),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: _sections.length,
              itemBuilder: (context, sectionIndex) {
                final section = _sections[sectionIndex];
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8, top: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(section.label, style: AppTextStyles.sectionLabel),
                          Text('عرض الكل',
                              style: AppTextStyles.caption
                                  .copyWith(color: AppColors.orange)),
                        ],
                      ),
                    ),
                    ...section.items.map(
                      (item) => AppCard(
                        onTap: () {},
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: AppColors.navy.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(item.icon, size: 17, color: AppColors.navy),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item.title, style: AppTextStyles.cardTitle),
                                  const SizedBox(height: 2),
                                  Text(item.subtitle, style: AppTextStyles.caption),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
