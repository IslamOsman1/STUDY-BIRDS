import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/app_theme.dart';
import '../../core/banner_carousel.dart';
import 'notifications_screen.dart';
import 'global_search_screen.dart';
import 'journey_tracker_screen.dart';
import 'activity_log_screen.dart';
import '../applications_documents_payments/applications_screens.dart';
import '../applications_documents_payments/documents_screens.dart';
import '../universities_programs_countries/universities_screens.dart';
import '../universities_programs_countries/countries_scholarships_screens.dart';
import '../visa_travel_accommodation/visa_travel_screens.dart';
import '../visa_travel_accommodation/accommodation_arrival_screens.dart';
import '../services_support/services_consultation_screens.dart';
import '../services_support/support_team_ai_screens.dart';

/// Drives the "Smart Home" behavior from spec point 96: the Home Dashboard
/// must read differently depending on where the student actually is in
/// their journey, not show the same generic cards to everyone.
enum StudentJourneyState { newStudent, applying, admitted, traveling, arrived }

class _SmartHomeContent {
  final String subtitle;
  final String journeyPath;
  final double progress;
  final String nextActionLabel;
  final String nextActionButton;

  const _SmartHomeContent({
    required this.subtitle,
    required this.journeyPath,
    required this.progress,
    required this.nextActionLabel,
    required this.nextActionButton,
  });
}

const Map<StudentJourneyState, _SmartHomeContent> _smartHomeMap = {
  StudentJourneyState.newStudent: _SmartHomeContent(
    subtitle: 'يلا نبدأ رحلتك سوا',
    journeyPath: 'لم تبدأ رحلتك بعد',
    progress: 0.0,
    nextActionLabel: 'ابدأ رحلتك باستكشاف الجامعات المناسبة ليك',
    nextActionButton: 'ابدأ الآن',
  ),
  StudentJourneyState.applying: _SmartHomeContent(
    subtitle: 'خطواتك القادمة نحو حلمك',
    journeyPath: 'تركيا ← إسطنبول ← العلاج الطبيعي',
    progress: 0.4,
    nextActionLabel: 'رفع شهادة اللغة',
    nextActionButton: 'أكمل الآن',
  ),
  StudentJourneyState.admitted: _SmartHomeContent(
    subtitle: 'مبروك القبول! خطوة واحدة كمان',
    journeyPath: 'تركيا ← إسطنبول ← العلاج الطبيعي',
    progress: 0.6,
    nextActionLabel: 'الخطوة القادمة: التأشيرة',
    nextActionButton: 'مركز التأشيرة',
  ),
  StudentJourneyState.traveling: _SmartHomeContent(
    subtitle: 'جهّز نفسك للسفر',
    journeyPath: 'تركيا ← إسطنبول ← العلاج الطبيعي',
    progress: 0.8,
    nextActionLabel: 'استعد للسفر: راجع معلومات رحلتك',
    nextActionButton: 'مركز السفر',
  ),
  StudentJourneyState.arrived: _SmartHomeContent(
    subtitle: 'وصلت بالسلامة! خطوة أخيرة',
    journeyPath: 'تركيا ← إسطنبول ← العلاج الطبيعي',
    progress: 0.9,
    nextActionLabel: 'أكمل تسجيلك في الجامعة',
    nextActionButton: 'تسجيل الجامعة',
  ),
};

class HomeDashboardScreen extends StatelessWidget {
  final StudentJourneyState journeyState;
  /// When true (used inside StudentAppShell), this screen has no Scaffold/
  /// bottom-nav of its own — the shell provides one shared bar instead.
  final bool embedInShell;
  const HomeDashboardScreen({super.key, this.journeyState = StudentJourneyState.applying, this.embedInShell = false});

  // Mock — in production this list comes from the admin panel/CMS (spec
  // points 75/76: dynamic, editable content, never hardcoded in the app).
  static const List<BannerItem> _banners = [
    BannerItem(imageUrl: 'https://picsum.photos/seed/studybirds1/800/400', linkUrl: 'https://studybirds.example/promo/turkey-intake'),
    BannerItem(imageUrl: 'https://picsum.photos/seed/studybirds2/800/400', linkUrl: 'https://studybirds.example/promo/scholarship'),
    BannerItem(imageUrl: 'https://picsum.photos/seed/studybirds3/800/400', linkUrl: 'https://studybirds.example/promo/referral'),
  ];

  Future<void> _openBannerLink(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  static const List<Map<String, dynamic>> _quickActions = [
    {'label': 'طلباتي', 'icon': Icons.description_outlined},
    {'label': 'الجامعات', 'icon': Icons.account_balance_outlined},
    {'label': 'مستنداتي', 'icon': Icons.folder_open_outlined},
    {'label': 'Bird AI', 'icon': null},
    {'label': 'استشارة', 'icon': Icons.support_agent_outlined},
  ];

  static const List<Map<String, String>> _scholarships = [
    {'title': 'منحة التميز الهندسي', 'uni': 'جامعة بهتشة شهير', 'discount': '30%'},
    {'title': 'العلوم الصحية', 'uni': 'جامعة أيدن', 'discount': '30%'},
  ];

  static const List<Map<String, String>> _recentActivity = [
    {'text': 'تم رفع جواز السفر', 'time': 'أمس'},
    {'text': 'تم تحديث حالة الطلب', 'time': 'قبل يومين'},
  ];

  Widget _quickActionScreen(String label) {
    switch (label) {
      case 'طلباتي':
        return const ApplicationsListScreen();
      case 'الجامعات':
        return const UniversitiesExplorerScreen();
      case 'مستنداتي':
        return const MyDocumentsScreen();
      case 'Bird AI':
        return const BirdAIChatScreen();
      case 'استشارة':
        return const ConsultationBookingScreen();
      default:
        return const UniversitiesExplorerScreen();
    }
  }

  Widget _nextActionScreen() {
    switch (journeyState) {
      case StudentJourneyState.newStudent:
        return const UniversitiesExplorerScreen();
      case StudentJourneyState.applying:
        return const MyDocumentsScreen();
      case StudentJourneyState.admitted:
        return const VisaCenterScreen();
      case StudentJourneyState.traveling:
        return const TravelCenterScreen();
      case StudentJourneyState.arrived:
        return const UniversityRegistrationScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final smart = _smartHomeMap[journeyState]!;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              // Hero — calmer gradient, softer frosted icon buttons, more breathing room.
              Container(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 34),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [AppColors.navy, AppColors.navy.withOpacity(0.92)],
                  ),
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        _HeroIconButton(
                          icon: Icons.menu_rounded,
                          onPressed: () {},
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              const Text('مرحباً أحمد', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 0.2)),
                              const SizedBox(height: 2),
                              // Smart Home: subtitle changes with journey state (spec point 96)
                              Text(smart.subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
                            ],
                          ),
                        ),
                        _HeroIconButton(
                          icon: Icons.notifications_none_rounded,
                          showDot: true,
                          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Container(
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.card)),
                      child: TextField(
                        readOnly: true,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GlobalSearchScreen())),
                        textAlign: TextAlign.right,
                        decoration: const InputDecoration(
                          hintText: 'ابحث عن جامعة، برنامج، دولة...',
                          hintStyle: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 13, horizontal: 12),
                          prefixIcon: Icon(Icons.search_rounded, color: AppColors.navy, size: 20),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Unified status card — journey + next action + the two key stats,
              // merged into one calm surface instead of three separate boxes.
              Transform.translate(
                offset: const Offset(0, -20),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: AppCard(
                    margin: EdgeInsets.zero,
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const JourneyTrackerScreen())),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('رحلتك الحالية', style: AppTextStyles.sectionLabel),
                                  const SizedBox(height: 4),
                                  Text(smart.journeyPath, style: AppTextStyles.body),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            SizedBox(
                              width: 44,
                              height: 44,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  CircularProgressIndicator(
                                    value: smart.progress,
                                    strokeWidth: 4,
                                    backgroundColor: AppColors.border,
                                    valueColor: const AlwaysStoppedAnimation(AppColors.orange),
                                  ),
                                  Text('${(smart.progress * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 10.5, color: AppColors.navy)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        // Next action — a quiet inline row with a subtle accent bar, not a loud filled box.
                        IntrinsicHeight(
                          child: Row(
                            children: [
                              Container(width: 3, decoration: BoxDecoration(color: AppColors.orange, borderRadius: BorderRadius.circular(2))),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('الخطوة القادمة', style: AppTextStyles.caption),
                                    const SizedBox(height: 2),
                                    Text(smart.nextActionLabel, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.textPrimary)),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              PrimaryButton(
                                label: smart.nextActionButton,
                                expand: false,
                                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => _nextActionScreen())),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Divider(height: 1, color: AppColors.border),
                        const SizedBox(height: 12),
                        // The two key stats — calm, inline, no bordered boxes.
                        Row(
                          children: [
                            Expanded(
                              child: _InlineStat(icon: Icons.person_outline_rounded, value: '85%', label: 'اكتمال الملف'),
                            ),
                            Container(width: 1, height: 32, color: AppColors.border),
                            Expanded(
                              child: _InlineStat(icon: Icons.description_outlined, value: '3', label: 'التطبيقات النشطة'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              BannerCarousel(
                banners: _banners,
                interval: const Duration(seconds: 3),
                onBannerTap: _openBannerLink,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    const Align(alignment: Alignment.centerRight, child: Text('الوصول السريع', style: AppTextStyles.sectionLabel)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: _quickActions
                          .map((q) => GestureDetector(
                                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => _quickActionScreen(q['label'] as String))),
                                child: Column(
                                  children: [
                                    Container(
                                      width: 52,
                                      height: 52,
                                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
                                      child: q['icon'] == null
                                          ? Padding(padding: const EdgeInsets.all(10), child: Image.asset('assets/images/logo_mark.png'))
                                          : Icon(q['icon'] as IconData, color: AppColors.navy),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(q['label'] as String, style: AppTextStyles.caption),
                                  ],
                                ),
                              ))
                          .toList(),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text('المنح الدراسية المتاحة', style: AppTextStyles.sectionLabel),
                        Text('عرض الكل', style: TextStyle(color: AppColors.orange, fontSize: 12.5, fontWeight: FontWeight.w700)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 110,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: _scholarships.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 10),
                        itemBuilder: (context, i) {
                          final s = _scholarships[i];
                          return GestureDetector(
                            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScholarshipsScreen())),
                            child: Container(
                              width: 190,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.card), border: Border.all(color: AppColors.border)),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  StatusBadge(label: 'خصم ${s['discount']}', color: AppColors.orange),
                                  const SizedBox(height: 8),
                                  Text(s['title']!, style: AppTextStyles.cardTitle),
                                  Text(s['uni']!, style: AppTextStyles.caption),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Align(alignment: Alignment.centerRight, child: Text('النشاط الأخير', style: AppTextStyles.sectionLabel)),
                    const SizedBox(height: 10),
                    ..._recentActivity.map(
                      (a) => AppCard(
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ActivityLogScreen())),
                        child: Row(
                          children: [
                            const Icon(Icons.check_circle_outline_rounded, color: AppColors.success, size: 18),
                            const SizedBox(width: 8),
                            Expanded(child: Text(a['text']!, style: AppTextStyles.body)),
                            Text(a['time']!, style: AppTextStyles.caption),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: embedInShell
            ? null
            : BottomNavigationBar(
                currentIndex: 0,
                selectedItemColor: AppColors.navy,
                unselectedItemColor: AppColors.textSecondary,
                type: BottomNavigationBarType.fixed,
                items: const [
                  BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
                  BottomNavigationBarItem(icon: Icon(Icons.timeline_rounded), label: 'الرحلة'),
                  BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), label: 'استكشاف'),
                  BottomNavigationBarItem(icon: Icon(Icons.miscellaneous_services_outlined), label: 'الخدمات'),
                  BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded), label: 'حسابي'),
                ],
              ),
      ),
    );
  }
}

/// Soft frosted circular icon button used in the hero — calmer than a bare
/// white icon floating on navy.
class _HeroIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  final bool showDot;
  const _HeroIconButton({required this.icon, required this.onPressed, this.showDot = false});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.12), shape: BoxShape.circle),
          child: IconButton(onPressed: onPressed, icon: Icon(icon, color: Colors.white, size: 20)),
        ),
        if (showDot)
          Positioned(
            right: 6,
            top: 6,
            child: Container(width: 7, height: 7, decoration: const BoxDecoration(color: AppColors.orange, shape: BoxShape.circle)),
          ),
      ],
    );
  }
}

/// Calm inline stat — icon, value, label, no border/box around it.
class _InlineStat extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _InlineStat({required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 16, color: AppColors.textSecondary),
        const SizedBox(width: 6),
        Text(value, style: AppTextStyles.cardTitle.copyWith(fontSize: 15)),
        const SizedBox(width: 4),
        Flexible(child: Text(label, style: AppTextStyles.caption, overflow: TextOverflow.ellipsis)),
      ],
    );
  }
}
