import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ImportantDate {
  final String title;
  final String subtitle;
  final String date;
  final int daysLeft;
  final IconData icon;

  const ImportantDate({
    required this.title,
    required this.subtitle,
    required this.date,
    required this.daysLeft,
    required this.icon,
  });

  Color get urgencyColor {
    if (daysLeft <= 3) return AppColors.danger;
    if (daysLeft <= 10) return AppColors.warning;
    return AppColors.success;
  }
}

class ImportantDatesScreen extends StatelessWidget {
  const ImportantDatesScreen({super.key});

  static const List<ImportantDate> _dates = [
    ImportantDate(
      title: 'موعد مقابلة التأشيرة',
      subtitle: 'القنصلية التركية - إسطنبول',
      date: '19 سبتمبر 2026',
      daysLeft: 5,
      icon: Icons.flight_takeoff_rounded,
    ),
    ImportantDate(
      title: 'الدفعة الثانية من الرسوم',
      subtitle: 'جامعة إسطنبول التقنية',
      date: '24 سبتمبر 2026',
      daysLeft: 10,
      icon: Icons.payments_rounded,
    ),
    ImportantDate(
      title: 'الموعد النهائي لتقديم الطلب',
      subtitle: 'برنامج بكالوريوس العلاج الطبيعي',
      date: '30 سبتمبر 2026',
      daysLeft: 16,
      icon: Icons.edit_document,
    ),
    ImportantDate(
      title: 'تاريخ السفر',
      subtitle: 'رحلة إسطنبول - رقم الرحلة TK123',
      date: '10 أكتوبر 2026',
      daysLeft: 26,
      icon: Icons.airplanemode_active_rounded,
    ),
    ImportantDate(
      title: 'تسجيل القبول بالجامعة',
      subtitle: 'الحرم الجامعي الرئيسي',
      date: '13 أكتوبر 2026',
      daysLeft: 29,
      icon: Icons.school_rounded,
    ),
    ImportantDate(
      title: 'موعد استلام السكن',
      subtitle: 'سكن الطلاب - المبنى B',
      date: '11 أكتوبر 2026',
      daysLeft: 27,
      icon: Icons.home_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'المواعيد المهمة',
      body: _dates.isEmpty
          ? const EmptyState(
              icon: Icons.event_note_rounded,
              title: 'لا توجد مواعيد قادمة',
              message: 'ستظهر هنا كل المواعيد النهائية المهمة في رحلتك.',
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _dates.length,
              itemBuilder: (context, index) {
                final d = _dates[index];
                return AppCard(
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: AppColors.navy.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(d.icon, size: 20, color: AppColors.navy),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d.title, style: AppTextStyles.cardTitle),
                            const SizedBox(height: 3),
                            Text(d.subtitle, style: AppTextStyles.caption),
                            const SizedBox(height: 4),
                            Text(d.date,
                                style: AppTextStyles.body
                                    .copyWith(color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      StatusBadge(
                        label: 'خلال ${d.daysLeft} يوم',
                        color: d.urgencyColor,
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
