import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// Per spec (point 12/13): the Journey is DYNAMIC — number and content of
/// stages can differ by country/university/service. This model and screen
/// treat the 14-stage list as example/default data, not a fixed enum.
enum StageStatus { upcoming, inProgress, completed, waitingStudent, waitingStudyBirds, waitingUniversity, delayed, requiresAction }

extension StageStatusX on StageStatus {
  String get label {
    switch (this) {
      case StageStatus.upcoming: return 'قادمة';
      case StageStatus.inProgress: return 'جارية الآن';
      case StageStatus.completed: return 'مكتملة';
      case StageStatus.waitingStudent: return 'بانتظارك';
      case StageStatus.waitingStudyBirds: return 'بانتظار Study Birds';
      case StageStatus.waitingUniversity: return 'بانتظار الجامعة';
      case StageStatus.delayed: return 'متأخرة';
      case StageStatus.requiresAction: return 'يتطلب إجراء منك';
    }
  }

  Color get color {
    switch (this) {
      case StageStatus.completed: return AppColors.success;
      case StageStatus.inProgress: return AppColors.orange;
      case StageStatus.waitingStudent: return AppColors.warning;
      case StageStatus.requiresAction: return AppColors.danger;
      case StageStatus.delayed: return AppColors.danger;
      case StageStatus.waitingStudyBirds: return AppColors.info;
      case StageStatus.waitingUniversity: return AppColors.info;
      case StageStatus.upcoming: return AppColors.neutral;
    }
  }
}

class JourneyStage {
  final String title;
  final StageStatus status;
  final String? note;
  const JourneyStage({required this.title, required this.status, this.note});
}

class JourneyTrackerScreen extends StatelessWidget {
  const JourneyTrackerScreen({super.key});

  // Example default stages — the real list/order/count comes from the
  // backend per country/university/service (spec: "Dynamic and not fixed").
  static const List<JourneyStage> _stages = [
    JourneyStage(title: 'استلام الملف', status: StageStatus.completed),
    JourneyStage(title: 'مراجعة المستندات', status: StageStatus.completed),
    JourneyStage(title: 'اختيار الجامعة', status: StageStatus.completed),
    JourneyStage(title: 'التقديم', status: StageStatus.completed),
    JourneyStage(title: 'مراجعة الجامعة', status: StageStatus.inProgress, note: 'الجامعة تراجع طلبك حاليًا'),
    JourneyStage(title: 'القبول المبدئي', status: StageStatus.upcoming),
    JourneyStage(title: 'الدفع', status: StageStatus.upcoming),
    JourneyStage(title: 'القبول النهائي', status: StageStatus.upcoming),
    JourneyStage(title: 'التأشيرة', status: StageStatus.upcoming),
    JourneyStage(title: 'السفر', status: StageStatus.upcoming),
    JourneyStage(title: 'الاستقبال', status: StageStatus.upcoming),
    JourneyStage(title: 'السكن', status: StageStatus.upcoming),
    JourneyStage(title: 'التسجيل في الجامعة', status: StageStatus.upcoming),
    JourneyStage(title: 'بدء الدراسة', status: StageStatus.upcoming),
  ];

  @override
  Widget build(BuildContext context) {
    final completedCount = _stages.where((s) => s.status == StageStatus.completed).length;
    final progress = completedCount / _stages.length;

    return AppScaffold(
      title: 'رحلتي',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('تركيا ← إسطنبول ← العلاج الطبيعي', style: AppTextStyles.cardTitle),
                      const SizedBox(height: 4),
                      Text('${(progress * 100).round()}% مكتمل — $completedCount من ${_stages.length} مرحلة', style: AppTextStyles.caption),
                    ],
                  ),
                ),
                SizedBox(
                  width: 46,
                  height: 46,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CircularProgressIndicator(value: progress, strokeWidth: 5, backgroundColor: AppColors.border, valueColor: const AlwaysStoppedAnimation(AppColors.orange)),
                      Text('${(progress * 100).round()}%', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.navy)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...List.generate(_stages.length, (i) {
            final stage = _stages[i];
            final isLast = i == _stages.length - 1;
            return IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: stage.status == StageStatus.completed ? AppColors.success : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(color: stage.status.color, width: 2),
                        ),
                        child: Center(
                          child: stage.status == StageStatus.completed
                              ? const Icon(Icons.check_rounded, size: 16, color: Colors.white)
                              : Text('${i + 1}', style: TextStyle(color: stage.status.color, fontWeight: FontWeight.w800, fontSize: 12)),
                        ),
                      ),
                      if (!isLast) Expanded(child: Container(width: 2, color: stage.status == StageStatus.completed ? AppColors.success : AppColors.border)),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 22, top: 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(stage.title,
                                    style: stage.status == StageStatus.inProgress
                                        ? AppTextStyles.cardTitle.copyWith(color: AppColors.orange)
                                        : AppTextStyles.cardTitle),
                              ),
                              StatusBadge(label: stage.status.label, color: stage.status.color),
                            ],
                          ),
                          if (stage.note != null) ...[
                            const SizedBox(height: 4),
                            Text(stage.note!, style: AppTextStyles.caption),
                          ],
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
