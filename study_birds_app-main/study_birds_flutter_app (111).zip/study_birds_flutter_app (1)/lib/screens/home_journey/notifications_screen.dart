import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

enum NotificationType {
  applicationUpdate,
  missingDocument,
  newAdmission,
  paymentDue,
  visaUpdate,
  appointmentReminder,
}

class AppNotification {
  final NotificationType type;
  final String message;
  final String timestamp;
  final String? actionLabel;
  final bool read;

  const AppNotification({
    required this.type,
    required this.message,
    required this.timestamp,
    this.actionLabel,
    this.read = false,
  });

  IconData get icon {
    switch (type) {
      case NotificationType.applicationUpdate:
        return Icons.description_rounded;
      case NotificationType.missingDocument:
        return Icons.warning_amber_rounded;
      case NotificationType.newAdmission:
        return Icons.school_rounded;
      case NotificationType.paymentDue:
        return Icons.payments_rounded;
      case NotificationType.visaUpdate:
        return Icons.flight_takeoff_rounded;
      case NotificationType.appointmentReminder:
        return Icons.event_rounded;
    }
  }

  Color get color {
    switch (type) {
      case NotificationType.applicationUpdate:
        return AppColors.info;
      case NotificationType.missingDocument:
        return AppColors.danger;
      case NotificationType.newAdmission:
        return AppColors.success;
      case NotificationType.paymentDue:
        return AppColors.warning;
      case NotificationType.visaUpdate:
        return AppColors.orange;
      case NotificationType.appointmentReminder:
        return AppColors.navy;
    }
  }
}

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  static const List<AppNotification> _notifications = [
    AppNotification(
      type: NotificationType.missingDocument,
      message: 'جامعتك المختارة تطلب نسخة أوضح من كشف الدرجات',
      timestamp: 'منذ 10 دقائق',
      actionLabel: 'رفع المستند',
      read: false,
    ),
    AppNotification(
      type: NotificationType.newAdmission,
      message: 'تهانينا! تم قبولك المبدئي في جامعة إسطنبول التقنية',
      timestamp: 'منذ ساعتين',
      actionLabel: 'عرض التفاصيل',
      read: false,
    ),
    AppNotification(
      type: NotificationType.paymentDue,
      message: 'يوجد دفعة مستحقة بقيمة 500\$ خلال 5 أيام',
      timestamp: 'اليوم، 9:14 ص',
      actionLabel: 'الدفع الآن',
      read: false,
    ),
    AppNotification(
      type: NotificationType.visaUpdate,
      message: 'تم تحديث حالة طلب التأشيرة إلى "قيد المراجعة"',
      timestamp: 'أمس',
      read: true,
    ),
    AppNotification(
      type: NotificationType.appointmentReminder,
      message: 'تذكير: موعد استشارتك مع المستشار التعليمي غدًا 11:00 ص',
      timestamp: 'أمس',
      actionLabel: 'عرض الموعد',
      read: true,
    ),
    AppNotification(
      type: NotificationType.applicationUpdate,
      message: 'تم تحديث حالة طلبك إلى "قيد المراجعة من الجامعة"',
      timestamp: 'منذ يومين',
      read: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'الإشعارات',
      actions: [
        TextButton(
          onPressed: () {},
          child: const Text('تعليم الكل كمقروء',
              style: TextStyle(color: Colors.white, fontSize: 12.5)),
        ),
      ],
      body: _notifications.isEmpty
          ? const EmptyState(
              icon: Icons.notifications_off_rounded,
              title: 'لا توجد إشعارات',
              message: 'ستصلك هنا كل التحديثات المهمة المتعلقة برحلتك.',
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _notifications.length,
              itemBuilder: (context, index) {
                final n = _notifications[index];
                return AppCard(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (!n.read)
                        Container(
                          margin: const EdgeInsets.only(left: 6, top: 4),
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: AppColors.orange,
                            shape: BoxShape.circle,
                          ),
                        ),
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: n.color.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(n.icon, size: 18, color: n.color),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(n.message,
                                style: AppTextStyles.body.copyWith(
                                  fontWeight:
                                      n.read ? FontWeight.w400 : FontWeight.w700,
                                )),
                            const SizedBox(height: 4),
                            Text(n.timestamp, style: AppTextStyles.caption),
                            if (n.actionLabel != null) ...[
                              const SizedBox(height: 10),
                              PrimaryButton(
                                label: n.actionLabel!,
                                onPressed: () {},
                                expand: false,
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
