import 'package:flutter/material.dart';
import '../../core/app_theme.dart';
import 'security_settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const List<Map<String, dynamic>> _sections = [
    {'label': 'المعلومات الشخصية', 'icon': Icons.person_outline_rounded, 'complete': true},
    {'label': 'المعلومات الأكاديمية', 'icon': Icons.school_outlined, 'complete': true},
    {'label': 'جواز السفر ومعلومات السفر', 'icon': Icons.badge_outlined, 'complete': true},
    {'label': 'معلومات ولي الأمر', 'icon': Icons.family_restroom_outlined, 'complete': false},
    {'label': 'جهة اتصال الطوارئ', 'icon': Icons.emergency_outlined, 'complete': false},
    {'label': 'تفضيلات الدراسة', 'icon': Icons.tune_rounded, 'complete': true},
    {'label': 'التفضيلات المالية', 'icon': Icons.account_balance_wallet_outlined, 'complete': false},
    {'label': 'تفضيلات اللغة', 'icon': Icons.translate_rounded, 'complete': true},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'الملف الشخصي',
      showBackButton: false,
      actions: [
        IconButton(
          icon: const Icon(Icons.settings_outlined, color: Colors.white),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
        ),
      ],
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text('اكتمال الملف الشخصي', style: AppTextStyles.caption),
                    Text('78%', style: TextStyle(color: AppColors.orange, fontWeight: FontWeight.w800)),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: const LinearProgressIndicator(
                    value: 0.78,
                    minHeight: 8,
                    backgroundColor: AppColors.border,
                    valueColor: AlwaysStoppedAnimation(AppColors.orange),
                  ),
                ),
                const SizedBox(height: 8),
                const Align(
                  alignment: Alignment.centerRight,
                  child: Text('الناقص: معلومات ولي الأمر، جهة اتصال الطوارئ، التفضيلات المالية', style: AppTextStyles.caption),
                ),
              ],
            ),
          ),
          ..._sections.map(
            (s) => AppCard(
              onTap: () {},
              child: Row(
                children: [
                  Icon(s['icon'] as IconData, color: AppColors.navy, size: 20),
                  const SizedBox(width: 12),
                  Expanded(child: Text(s['label'] as String, style: AppTextStyles.cardTitle)),
                  Icon(
                    s['complete'] as bool ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                    size: 16,
                    color: s['complete'] as bool ? AppColors.success : AppColors.warning,
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          AppCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ReferralProgramScreen())),
            child: Row(children: const [Icon(Icons.card_giftcard_rounded, color: AppColors.navy), SizedBox(width: 12), Expanded(child: Text('برنامج الإحالة', style: AppTextStyles.cardTitle)), Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary)]),
          ),
          AppCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyWalletScreen())),
            child: Row(children: const [Icon(Icons.account_balance_wallet_outlined, color: AppColors.navy), SizedBox(width: 12), Expanded(child: Text('محفظتي', style: AppTextStyles.cardTitle)), Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary)]),
          ),
          AppCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FavoritesScreen())),
            child: Row(children: const [Icon(Icons.favorite_border_rounded, color: AppColors.navy), SizedBox(width: 12), Expanded(child: Text('المفضلة', style: AppTextStyles.cardTitle)), Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary)]),
          ),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'الإعدادات',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            onTap: () {},
            child: Row(
              children: const [
                Icon(Icons.lock_outline_rounded, color: AppColors.navy),
                SizedBox(width: 12),
                Expanded(child: Text('تغيير كلمة المرور', style: AppTextStyles.cardTitle)),
                Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
              ],
            ),
          ),
          AppCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SecuritySettingsScreen())),
            child: Row(
              children: const [
                Icon(Icons.shield_outlined, color: AppColors.navy),
                SizedBox(width: 12),
                Expanded(child: Text('الأمان (2FA، الجلسات النشطة)', style: AppTextStyles.cardTitle)),
                Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
              ],
            ),
          ),
          AppCard(
            child: Row(
              children: const [
                Icon(Icons.notifications_none_rounded, color: AppColors.navy),
                SizedBox(width: 12),
                Expanded(child: Text('الإشعارات', style: AppTextStyles.cardTitle)),
                _MiniSwitch(),
              ],
            ),
          ),
          AppCard(
            onTap: () {},
            child: Row(
              children: const [
                Icon(Icons.language_rounded, color: AppColors.navy),
                SizedBox(width: 12),
                Expanded(child: Text('اللغة', style: AppTextStyles.cardTitle)),
                Text('العربية', style: AppTextStyles.caption),
              ],
            ),
          ),
          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.logout_rounded, color: AppColors.danger, size: 18),
            label: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.danger)),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(double.infinity, 48),
              side: const BorderSide(color: AppColors.danger),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniSwitch extends StatefulWidget {
  const _MiniSwitch();
  @override
  State<_MiniSwitch> createState() => _MiniSwitchState();
}

class _MiniSwitchState extends State<_MiniSwitch> {
  bool _on = true;
  @override
  Widget build(BuildContext context) {
    return Switch(
      value: _on,
      activeColor: AppColors.orange,
      onChanged: (v) => setState(() => _on = v),
    );
  }
}

class ReferralProgramScreen extends StatelessWidget {
  const ReferralProgramScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'برنامج الإحالة',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            AppCard(
              child: Column(
                children: [
                  const Text('رمز الإحالة الخاص بك', style: AppTextStyles.caption),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: AppColors.navy.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(AppRadius.button),
                      border: Border.all(color: AppColors.navy.withOpacity(0.2), style: BorderStyle.solid),
                    ),
                    child: const Text('AHMAD-2026', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.navy)),
                  ),
                  const SizedBox(height: 12),
                  PrimaryButton(label: 'مشاركة', onPressed: () {}, icon: Icons.share_rounded, expand: false),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: const [
                Expanded(child: _StatCard(value: '12', label: 'الإحالات')),
                SizedBox(width: 10),
                Expanded(child: _StatCard(value: '5', label: 'الناجحة')),
                SizedBox(width: 10),
                Expanded(child: _StatCard(value: '75\$', label: 'المكافآت')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  const _StatCard({required this.value, required this.label});
  @override
  Widget build(BuildContext context) {
    return AppCard(
      margin: EdgeInsets.zero,
      child: Column(
        children: [
          Text(value, style: AppTextStyles.screenTitle.copyWith(fontSize: 18)),
          const SizedBox(height: 4),
          Text(label, style: AppTextStyles.caption, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class MyWalletScreen extends StatelessWidget {
  const MyWalletScreen({super.key});

  static const List<Map<String, String>> _tx = [
    {'desc': 'مكافأة إحالة ناجحة', 'amount': '+15\$', 'date': '5 سبتمبر 2026'},
    {'desc': 'استخدام رصيد في خدمة الترجمة', 'amount': '-20\$', 'date': '2 سبتمبر 2026'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'محفظتي',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const [
                _StatCard(value: '75\$', label: 'رصيد الإحالات'),
                _StatCard(value: '30\$', label: 'الخصومات'),
                _StatCard(value: '20\$', label: 'رصيد الخدمات'),
              ],
            ),
          ),
          const Text('سجل المعاملات', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          ..._tx.map(
            (t) => AppCard(
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t['desc']!, style: AppTextStyles.body),
                        Text(t['date']!, style: AppTextStyles.caption),
                      ],
                    ),
                  ),
                  Text(t['amount']!,
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: t['amount']!.startsWith('+') ? AppColors.success : AppColors.danger,
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  static const Map<String, List<String>> _groups = {
    'الجامعات': ['جامعة إسطنبول التقنية', 'جامعة بهتشة شهير'],
    'البرامج': ['بكالوريوس علوم الحاسوب'],
    'الدول': ['تركيا'],
  };

  @override
  Widget build(BuildContext context) {
    final hasFavorites = _groups.values.any((v) => v.isNotEmpty);
    return AppScaffold(
      title: 'المفضلة',
      body: !hasFavorites
          ? const EmptyState(
              icon: Icons.favorite_border_rounded,
              title: 'لا يوجد لديك عناصر مفضلة',
              message: 'احفظ الجامعات والبرامج اللي تعجبك عشان ترجعلها بسهولة.',
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: _groups.entries
                  .where((e) => e.value.isNotEmpty)
                  .map(
                    (e) => Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(e.key, style: AppTextStyles.sectionLabel),
                        const SizedBox(height: 10),
                        ...e.value.map(
                          (item) => AppCard(
                            child: Row(
                              children: [
                                Expanded(child: Text(item, style: AppTextStyles.cardTitle)),
                                const Icon(Icons.favorite_rounded, color: AppColors.orange, size: 20),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  )
                  .toList(),
            ),
    );
  }
}
