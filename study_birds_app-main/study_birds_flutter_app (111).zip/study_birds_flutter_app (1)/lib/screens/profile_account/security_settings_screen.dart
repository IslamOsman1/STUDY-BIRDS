import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class SecuritySettingsScreen extends StatefulWidget {
  const SecuritySettingsScreen({super.key});

  @override
  State<SecuritySettingsScreen> createState() => _SecuritySettingsScreenState();
}

class _SecuritySettingsScreenState extends State<SecuritySettingsScreen> {
  bool _twoFactorEnabled = false;
  bool _biometricEnabled = true;

  static const List<Map<String, String>> _sessions = [
    {'device': 'iPhone 15 — إسطنبول', 'lastActive': 'نشط الآن', 'current': 'true'},
    {'device': 'Chrome — ويندوز', 'lastActive': 'قبل 3 أيام', 'current': 'false'},
    {'device': 'Samsung Galaxy — القاهرة', 'lastActive': 'قبل أسبوع', 'current': 'false'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'الأمان',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('حماية الحساب', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          AppCard(
            onTap: () {},
            child: Row(
              children: const [
                Icon(Icons.lock_reset_rounded, color: AppColors.navy),
                SizedBox(width: 12),
                Expanded(child: Text('تغيير كلمة المرور', style: AppTextStyles.cardTitle)),
                Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
              ],
            ),
          ),
          AppCard(
            child: Row(
              children: [
                const Icon(Icons.shield_outlined, color: AppColors.navy),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('التحقق بخطوتين (2FA)', style: AppTextStyles.cardTitle),
                      Text('طبقة حماية إضافية عند تسجيل الدخول', style: AppTextStyles.caption),
                    ],
                  ),
                ),
                Switch(value: _twoFactorEnabled, activeColor: AppColors.orange, onChanged: (v) => setState(() => _twoFactorEnabled = v)),
              ],
            ),
          ),
          AppCard(
            child: Row(
              children: [
                const Icon(Icons.fingerprint_rounded, color: AppColors.navy),
                const SizedBox(width: 12),
                const Expanded(child: Text('تسجيل الدخول بالبصمة', style: AppTextStyles.cardTitle)),
                Switch(value: _biometricEnabled, activeColor: AppColors.orange, onChanged: (v) => setState(() => _biometricEnabled = v)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text('الجلسات النشطة', style: AppTextStyles.sectionLabel),
            ],
          ),
          const SizedBox(height: 10),
          ..._sessions.map(
            (s) => AppCard(
              child: Row(
                children: [
                  Icon(Icons.devices_rounded, color: s['current'] == 'true' ? AppColors.success : AppColors.textSecondary, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s['device']!, style: AppTextStyles.cardTitle),
                        Text(s['lastActive']!, style: AppTextStyles.caption),
                      ],
                    ),
                  ),
                  if (s['current'] == 'true')
                    const StatusBadge(label: 'الجهاز الحالي', color: AppColors.success)
                  else
                    TextButton(onPressed: () {}, child: const Text('إنهاء', style: TextStyle(color: AppColors.danger))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () async {
              await showAppConfirmDialog(
                context,
                title: 'تسجيل الخروج من كل الأجهزة',
                message: 'سيتم تسجيل خروجك من كل الأجهزة المتصلة بحسابك، بما في ذلك هذا الجهاز. متابعة؟',
                confirmLabel: 'تسجيل الخروج من الكل',
                danger: true,
              );
            },
            icon: const Icon(Icons.logout_rounded, color: AppColors.danger, size: 18),
            label: const Text('تسجيل الخروج من كل الأجهزة', style: TextStyle(color: AppColors.danger)),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(double.infinity, 48),
              side: const BorderSide(color: AppColors.danger),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
            ),
          ),
        ],
      ),
    );
  }
}
