import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// Agent Mode Home — student-management-first. Agent sees/manages only
/// their own assigned students, plus their own commission/financial info.
class AgentDashboardScreen extends StatelessWidget {
  const AgentDashboardScreen({super.key});

  static const List<Map<String, dynamic>> _students = [
    {'name': 'أحمد خالد', 'status': 'قيد المراجعة', 'color': AppColors.info, 'country': 'تركيا'},
    {'name': 'منى سالم', 'status': 'مطلوب مستندات', 'color': AppColors.warning, 'country': 'جورجيا'},
    {'name': 'يوسف عادل', 'status': 'قبول نهائي', 'color': AppColors.success, 'country': 'ماليزيا'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'لوحة الوكيل',
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.person_add_alt_rounded, color: Colors.white)),
      ],
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: const [
              Expanded(child: _StatCard(value: '24', label: 'إجمالي طلابي')),
              SizedBox(width: 10),
              Expanded(child: _StatCard(value: '6', label: 'بانتظار إجراء')),
              SizedBox(width: 10),
              Expanded(child: _StatCard(value: '1,240\$', label: 'عمولتي هذا الشهر')),
            ],
          ),
          const SizedBox(height: 4),
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.card), border: Border.all(color: AppColors.border)),
            child: const TextField(
              textAlign: TextAlign.right,
              decoration: InputDecoration(
                hintText: 'ابحث باسم الطالب...',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                prefixIcon: Icon(Icons.search_rounded, color: AppColors.navy),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 36,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                _Chip(label: 'الحالة'),
                SizedBox(width: 8),
                _Chip(label: 'الدولة'),
                SizedBox(width: 8),
                _Chip(label: 'الجامعة'),
                SizedBox(width: 8),
                _Chip(label: 'المستشار'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text('طلابي', style: AppTextStyles.sectionLabel),
              Text('عرض الكل', style: TextStyle(color: AppColors.orange, fontSize: 12.5, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 10),
          ..._students.map(
            (s) => AppCard(
              onTap: () {},
              child: Row(
                children: [
                  const CircleAvatar(radius: 20, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, color: AppColors.navy, size: 18)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s['name'] as String, style: AppTextStyles.cardTitle),
                        Text(s['country'] as String, style: AppTextStyles.caption),
                      ],
                    ),
                  ),
                  StatusBadge(label: s['status'] as String, color: s['color'] as Color),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  const _StatCard({required this.value, required this.label});
  @override
  Widget build(BuildContext context) {
    return AppCard(
      margin: EdgeInsets.zero,
      child: Column(
        children: [
          Text(value, style: AppTextStyles.screenTitle.copyWith(fontSize: 16)),
          const SizedBox(height: 2),
          Text(label, style: AppTextStyles.caption, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip({required this.label});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      alignment: Alignment.center,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.chip), border: Border.all(color: AppColors.border)),
      child: Text(label, style: AppTextStyles.body.copyWith(fontSize: 12.5)),
    );
  }
}
