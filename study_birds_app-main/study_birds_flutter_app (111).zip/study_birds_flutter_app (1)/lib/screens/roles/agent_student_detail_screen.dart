import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class AgentStudentDetailScreen extends StatelessWidget {
  const AgentStudentDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'أحمد خالد',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Row(
              children: const [
                CircleAvatar(radius: 26, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, color: AppColors.navy)),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('أحمد خالد', style: AppTextStyles.cardTitle),
                      Text('تركيا — جامعة إسطنبول التقنية', style: AppTextStyles.caption),
                    ],
                  ),
                ),
                StatusBadge(label: 'قيد المراجعة', color: AppColors.info),
              ],
            ),
          ),
          const Text('حالة الطلب', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('الطلب قيد المراجعة من الجامعة، بانتظار رد خلال أسبوع تقريبًا.', style: AppTextStyles.body),
              ],
            ),
          ),
          const Text('المستندات', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          AppCard(
            child: Column(
              children: const [
                _MiniRow(label: 'جواز السفر', value: 'مكتمل', color: AppColors.success),
                Divider(height: 20),
                _MiniRow(label: 'كشف الدرجات', value: 'ناقص', color: AppColors.warning),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: OutlinedButton(onPressed: () {}, child: const Text('رفع مستند نيابةً عنه'))),
              const SizedBox(width: 10),
              Expanded(child: PrimaryButton(label: 'مراسلة الطالب', onPressed: () {})),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniRow extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _MiniRow({required this.label, required this.value, required this.color});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.body),
        StatusBadge(label: value, color: color),
      ],
    );
  }
}

class MyCommissionsScreen extends StatelessWidget {
  const MyCommissionsScreen({super.key});

  static const List<Map<String, String>> _commissions = [
    {'student': 'أحمد خالد', 'amount': '150\$', 'status': 'مدفوعة'},
    {'student': 'منى سالم', 'amount': '120\$', 'status': 'قيد المعالجة'},
    {'student': 'يوسف عادل', 'amount': '200\$', 'status': 'مدفوعة'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'عمولاتي',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const [
                _Stat(value: '1,240\$', label: 'هذا الشهر'),
                _Stat(value: '8,600\$', label: 'الإجمالي'),
              ],
            ),
          ),
          const Text('التفاصيل', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          ..._commissions.map(
            (c) => AppCard(
              child: Row(
                children: [
                  Expanded(child: Text(c['student']!, style: AppTextStyles.cardTitle)),
                  Text(c['amount']!, style: AppTextStyles.cardTitle),
                  const SizedBox(width: 8),
                  StatusBadge(label: c['status']!, color: c['status'] == 'مدفوعة' ? AppColors.success : AppColors.warning),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String value;
  final String label;
  const _Stat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: AppTextStyles.screenTitle.copyWith(fontSize: 18)),
        const SizedBox(height: 2),
        Text(label, style: AppTextStyles.caption),
      ],
    );
  }
}
