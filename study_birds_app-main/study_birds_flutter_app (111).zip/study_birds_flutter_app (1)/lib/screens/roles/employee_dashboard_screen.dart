import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// Employee Mode Home — built around "what do I need to do today".
/// The same template adapts its focus by role (Admission, Sales, Finance,
/// Support, Manager, etc.) by changing which counts/sections are emphasized —
/// per spec, each role sees only what's relevant to them.
class EmployeeDashboardScreen extends StatelessWidget {
  final String roleName;
  const EmployeeDashboardScreen({super.key, this.roleName = 'مسؤول قبول (Admission)'});

  // Counts shown would be filtered server-side per role/permission in the real app.
  static const List<Map<String, dynamic>> _todayCounts = [
    {'label': 'مهام اليوم', 'value': '8', 'icon': Icons.task_alt_rounded},
    {'label': 'مراجعة مستندات', 'value': '5', 'icon': Icons.description_outlined},
    {'label': 'متابعات', 'value': '3', 'icon': Icons.follow_the_signs_outlined},
    {'label': 'حالات عاجلة', 'value': '2', 'icon': Icons.priority_high_rounded},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'لوحة الموظف',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(color: AppColors.navy.withOpacity(0.08), borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.badge_rounded, color: AppColors.navy),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('مرحباً كريم', style: AppTextStyles.cardTitle),
                      Text(roleName, style: AppTextStyles.caption),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Text('ماذا يجب أن أفعل اليوم؟', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: _todayCounts
                .map((c) => Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.card), border: Border.all(color: AppColors.border)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(c['icon'] as IconData, color: AppColors.orange, size: 20),
                          Text(c['value'] as String, style: AppTextStyles.screenTitle.copyWith(fontSize: 22)),
                          Text(c['label'] as String, style: AppTextStyles.caption),
                        ],
                      ),
                    ))
                .toList(),
          ),
          const SizedBox(height: 8),
          const Text('حالات تحتاج انتباهك', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          AppCard(
            child: Row(
              children: const [
                Icon(Icons.priority_high_rounded, color: AppColors.danger, size: 18),
                SizedBox(width: 8),
                Expanded(child: Text('طالب "منى سالم" بانتظار رد منذ 3 أيام', style: AppTextStyles.body)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TaskItem {
  final String title;
  final String priority;
  final Color priorityColor;
  final String dueDate;
  final String status;

  const TaskItem({required this.title, required this.priority, required this.priorityColor, required this.dueDate, required this.status});
}

class MyTasksScreen extends StatelessWidget {
  const MyTasksScreen({super.key});

  static const List<TaskItem> _tasks = [
    TaskItem(title: 'مراجعة مستندات أحمد خالد', priority: 'عاجل', priorityColor: AppColors.danger, dueDate: 'اليوم', status: 'لم يبدأ'),
    TaskItem(title: 'متابعة دفعة منى سالم', priority: 'متوسط', priorityColor: AppColors.warning, dueDate: 'غدًا', status: 'قيد التنفيذ'),
    TaskItem(title: 'الرد على استفسار يوسف عادل', priority: 'عادي', priorityColor: AppColors.info, dueDate: 'خلال يومين', status: 'لم يبدأ'),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مهامي',
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _tasks.length,
        itemBuilder: (context, i) {
          final t = _tasks[i];
          return AppCard(
            onTap: () {},
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(t.title, style: AppTextStyles.cardTitle)),
                    StatusBadge(label: t.priority, color: t.priorityColor),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('الاستحقاق: ${t.dueDate}', style: AppTextStyles.caption),
                    Text(t.status, style: AppTextStyles.caption),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
