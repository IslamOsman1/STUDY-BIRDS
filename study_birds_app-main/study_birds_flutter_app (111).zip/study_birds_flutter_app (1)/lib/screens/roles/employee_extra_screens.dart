import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class MyStudentsQueueScreen extends StatelessWidget {
  const MyStudentsQueueScreen({super.key});

  static const List<Map<String, dynamic>> _students = [
    {'name': 'أحمد خالد', 'status': 'مراجعة مستندات', 'color': AppColors.info},
    {'name': 'منى سالم', 'status': 'بانتظار دفعة', 'color': AppColors.warning},
    {'name': 'يوسف عادل', 'status': 'حالة عاجلة', 'color': AppColors.danger},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'طلابي',
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _students.length,
        itemBuilder: (context, i) {
          final s = _students[i];
          return AppCard(
            onTap: () {},
            child: Row(
              children: [
                const CircleAvatar(radius: 20, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, color: AppColors.navy, size: 18)),
                const SizedBox(width: 12),
                Expanded(child: Text(s['name'] as String, style: AppTextStyles.cardTitle)),
                StatusBadge(label: s['status'] as String, color: s['color'] as Color),
              ],
            ),
          );
        },
      ),
    );
  }
}

class MessageThread {
  final String name;
  final String lastMessage;
  final String time;
  final bool unread;
  const MessageThread({required this.name, required this.lastMessage, required this.time, this.unread = false});
}

class MessagesInboxScreen extends StatelessWidget {
  const MessagesInboxScreen({super.key});

  static const List<MessageThread> _threads = [
    MessageThread(name: 'أحمد خالد', lastMessage: 'هل الترجمة المعتمدة مقبولة؟', time: '10:24 ص', unread: true),
    MessageThread(name: 'جامعة إسطنبول التقنية', lastMessage: 'تم استلام الطلب، جاري المراجعة', time: 'أمس'),
    MessageThread(name: 'منى سالم', lastMessage: 'شكرًا جزيلًا على المساعدة!', time: 'أمس'),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'الرسائل',
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _threads.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          final t = _threads[i];
          return AppCard(
            margin: EdgeInsets.zero,
            onTap: () {},
            child: Row(
              children: [
                const CircleAvatar(radius: 20, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, color: AppColors.navy, size: 18)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.name, style: t.unread ? AppTextStyles.cardTitle : AppTextStyles.body),
                      Text(t.lastMessage, style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(t.time, style: AppTextStyles.caption),
                    if (t.unread) Container(margin: const EdgeInsets.only(top: 4), width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.orange, shape: BoxShape.circle)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Manager Overview — spec point 110: short indicators only, not a full ERP.
class ManagerOverviewScreen extends StatelessWidget {
  const ManagerOverviewScreen({super.key});

  static const List<Map<String, dynamic>> _metrics = [
    {'label': 'طلاب جدد', 'value': '18', 'color': AppColors.info},
    {'label': 'طلبات', 'value': '64', 'color': AppColors.navy},
    {'label': 'معلقة', 'value': '11', 'color': AppColors.warning},
    {'label': 'متأخرة', 'value': '3', 'color': AppColors.danger},
    {'label': 'مكتملة', 'value': '42', 'color': AppColors.success},
    {'label': 'عاجلة', 'value': '2', 'color': AppColors.danger},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'نظرة عامة — مدير الفرع',
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _metrics.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.3),
        itemBuilder: (context, i) {
          final m = _metrics[i];
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.card), border: Border.all(color: AppColors.border)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(m['value'] as String, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: m['color'] as Color)),
                Text(m['label'] as String, style: AppTextStyles.caption),
              ],
            ),
          );
        },
      ),
    );
  }
}
