import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// Parent Mode Home — "My Student" view.
/// Shows only what a parent should see: application/admission/payment/visa/
/// travel/accommodation/notifications for the selected child. Zero visibility
/// into Study Birds internal/employee data. Supports multiple children.
class ParentDashboardScreen extends StatefulWidget {
  const ParentDashboardScreen({super.key});

  @override
  State<ParentDashboardScreen> createState() => _ParentDashboardScreenState();
}

class _ParentDashboardScreenState extends State<ParentDashboardScreen> {
  int _selectedChild = 0;
  static const List<String> _children = ['أحمد', 'سارة'];

  static const List<Map<String, dynamic>> _sections = [
    {'label': 'حالة الطلب', 'value': 'قيد المراجعة من الجامعة', 'icon': Icons.description_outlined, 'color': AppColors.info},
    {'label': 'القبول', 'value': 'بانتظار القرار', 'icon': Icons.school_outlined, 'color': AppColors.warning},
    {'label': 'الدفعات', 'value': 'دفعة مستحقة خلال 5 أيام', 'icon': Icons.payments_outlined, 'color': AppColors.warning},
    {'label': 'التأشيرة', 'value': 'قيد التحضير', 'icon': Icons.flight_takeoff_outlined, 'color': AppColors.info},
    {'label': 'السفر', 'value': 'لم يحدد بعد', 'icon': Icons.card_travel_outlined, 'color': AppColors.neutral},
    {'label': 'السكن', 'value': 'لم يطلب بعد', 'icon': Icons.home_outlined, 'color': AppColors.neutral},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'حساب ولي الأمر',
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded, color: Colors.white)),
      ],
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('ابني/ابنتي', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          SizedBox(
            height: 40,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _children.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final selected = i == _selectedChild;
                return GestureDetector(
                  onTap: () => setState(() => _selectedChild = i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? AppColors.navy : Colors.white,
                      borderRadius: BorderRadius.circular(AppRadius.chip),
                      border: Border.all(color: selected ? AppColors.navy : AppColors.border),
                    ),
                    child: Text(_children[i],
                        style: TextStyle(color: selected ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.w700, fontSize: 13)),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          AppCard(
            child: Row(
              children: [
                const CircleAvatar(radius: 24, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, color: AppColors.navy)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_children[_selectedChild], style: AppTextStyles.cardTitle),
                      const Text('جامعة إسطنبول التقنية — العلاج الطبيعي', style: AppTextStyles.caption),
                    ],
                  ),
                ),
                const StatusBadge(label: '40% من الرحلة', color: AppColors.orange),
              ],
            ),
          ),
          const SizedBox(height: 4),
          const Text('نظرة عامة', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          ..._sections.map(
            (s) => AppCard(
              onTap: () {},
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(color: (s['color'] as Color).withOpacity(0.12), borderRadius: BorderRadius.circular(9)),
                    child: Icon(s['icon'] as IconData, color: s['color'] as Color, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s['label'] as String, style: AppTextStyles.cardTitle),
                        Text(s['value'] as String, style: AppTextStyles.caption),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          PrimaryButton(label: 'التواصل مع المستشار', onPressed: () {}, icon: Icons.chat_bubble_outline_rounded),
        ],
      ),
    );
  }
}
