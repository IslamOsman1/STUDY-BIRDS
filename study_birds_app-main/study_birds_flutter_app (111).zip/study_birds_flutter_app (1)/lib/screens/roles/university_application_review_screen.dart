import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class UniversityApplicationReviewScreen extends StatelessWidget {
  const UniversityApplicationReviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مراجعة طلب — أحمد خالد',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('بكالوريوس العلاج الطبيعي', style: AppTextStyles.cardTitle),
                SizedBox(height: 10),
                _Row(label: 'الفصل الدراسي', value: 'خريف 2026'),
                Divider(height: 20),
                _Row(label: 'اللغة', value: 'الإنجليزية'),
                Divider(height: 20),
                _Row(label: 'الوكيل', value: 'وكيل معتمد - القاهرة'),
              ],
            ),
          ),
          const Text('المستندات المقدمة', style: AppTextStyles.sectionLabel),
          const SizedBox(height: 10),
          AppCard(
            child: Column(
              children: const [
                _DocRow(name: 'جواز السفر', complete: true),
                Divider(height: 18),
                _DocRow(name: 'شهادة الثانوية', complete: true),
                Divider(height: 18),
                _DocRow(name: 'كشف الدرجات', complete: false),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.border)),
                  child: const Text('طلب مستند إضافي'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.danger)),
                  child: const Text('رفض الطلب', style: TextStyle(color: AppColors.danger)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          PrimaryButton(label: 'رفع خطاب القبول', onPressed: () {}, icon: Icons.upload_file_rounded),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.caption),
        Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class _DocRow extends StatelessWidget {
  final String name;
  final bool complete;
  const _DocRow({required this.name, required this.complete});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(complete ? Icons.check_circle_rounded : Icons.error_outline_rounded, size: 18, color: complete ? AppColors.success : AppColors.warning),
        const SizedBox(width: 10),
        Expanded(child: Text(name, style: AppTextStyles.body)),
        TextButton(onPressed: () {}, child: const Text('معاينة', style: TextStyle(fontSize: 12))),
      ],
    );
  }
}
