import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// University Mode Home — application-processing-first. The university
/// sees/acts only on applications assigned to it; no visibility into data
/// belonging to other universities or Study Birds internals.
class UniversityDashboardScreen extends StatelessWidget {
  const UniversityDashboardScreen({super.key});

  static const List<Map<String, dynamic>> _queue = [
    {'name': 'أحمد خالد', 'program': 'العلاج الطبيعي', 'status': 'مستندات مكتملة', 'color': AppColors.success},
    {'name': 'منى سالم', 'program': 'إدارة الأعمال', 'status': 'بانتظار مستند', 'color': AppColors.warning},
    {'name': 'يوسف عادل', 'program': 'علوم الحاسوب', 'status': 'قيد المراجعة', 'color': AppColors.info},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'لوحة الجامعة',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: const [
              Expanded(child: _StatCard(value: '58', label: 'طلبات هذا الفصل')),
              SizedBox(width: 10),
              Expanded(child: _StatCard(value: '14', label: 'بانتظار قراري')),
              SizedBox(width: 10),
              Expanded(child: _StatCard(value: '9', label: 'مقبولين')),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text('طلبات بانتظار المراجعة', style: AppTextStyles.sectionLabel),
              Text('عرض الكل', style: TextStyle(color: AppColors.orange, fontSize: 12.5, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 10),
          ..._queue.map(
            (q) => AppCard(
              onTap: () {},
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(q['name'] as String, style: AppTextStyles.cardTitle)),
                      StatusBadge(label: q['status'] as String, color: q['color'] as Color),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(q['program'] as String, style: AppTextStyles.caption),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () {},
                          style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.border)),
                          child: const Text('طلب مستند إضافي', style: TextStyle(fontSize: 12)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: PrimaryButton(label: 'رفع قرار القبول', onPressed: () {}, expand: true)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  const _StatCard({required this.value, required this.label});
  @override
  Widget build(BuildContext context) {
    return AppCard(
      margin: EdgeInsets.zero,
      child: Column(
        children: [
          Text(value, style: AppTextStyles.screenTitle.copyWith(fontSize: 16)),
          const SizedBox(height: 2),
          Text(label, style: AppTextStyles.caption, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
