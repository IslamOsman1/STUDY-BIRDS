import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class SimpleMessage {
  final bool fromMe;
  final String text;
  final String time;
  const SimpleMessage({required this.fromMe, required this.text, required this.time});
}

/// In-App Messaging — spec point 46: conversation tied to the
/// Student/Application context, not a generic chat.
class ConversationThreadScreen extends StatelessWidget {
  final String contactName;
  const ConversationThreadScreen({super.key, this.contactName = 'سارة أحمد — مستشارة تعليمية'});

  static const List<SimpleMessage> _messages = [
    SimpleMessage(fromMe: false, text: 'أهلاً أحمد، وصلني طلبك بخصوص الترجمة، هل عندك المستند الأصلي جاهز؟', time: '10:12 ص'),
    SimpleMessage(fromMe: true, text: 'أيوة جاهز، أرفعه فين بالظبط؟', time: '10:15 ص'),
    SimpleMessage(fromMe: false, text: 'من شاشة مستنداتي، تحت بند "شهادة الميلاد" هتلاقي زر رفع مستند.', time: '10:16 ص'),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: contactName,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            color: AppColors.navy.withOpacity(0.05),
            child: const Text('هذه المحادثة مرتبطة بطلبك: جامعة إسطنبول التقنية', style: AppTextStyles.caption, textAlign: TextAlign.center),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, i) {
                final m = _messages[i];
                return Align(
                  alignment: m.fromMe ? Alignment.centerLeft : Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: m.fromMe ? AppColors.navy : Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: m.fromMe ? null : Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(m.text, style: TextStyle(color: m.fromMe ? Colors.white : AppColors.textPrimary, fontSize: 13.5)),
                        const SizedBox(height: 4),
                        Text(m.time, style: TextStyle(fontSize: 10, color: m.fromMe ? Colors.white70 : AppColors.textSecondary)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30), border: Border.all(color: AppColors.border)),
              child: Row(
                children: [
                  IconButton(onPressed: () {}, icon: const Icon(Icons.send_rounded, color: AppColors.orange)),
                  const Expanded(child: TextField(textAlign: TextAlign.right, decoration: InputDecoration(hintText: 'اكتب رسالتك...', border: InputBorder.none))),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.attach_file_rounded, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Emergency/Urgent Support — spec point 101: architecture placeholder for
/// students already abroad, not necessarily a v1 priority feature.
class EmergencySupportScreen extends StatelessWidget {
  const EmergencySupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مساعدة عاجلة',
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(color: AppColors.danger.withOpacity(0.1), shape: BoxShape.circle),
              child: const Icon(Icons.emergency_share_rounded, color: AppColors.danger, size: 40),
            ),
            const SizedBox(height: 16),
            const Text('محتاج مساعدة عاجلة؟', style: AppTextStyles.screenTitle),
            const SizedBox(height: 8),
            const Text(
              'لو انت حاليًا خارج بلدك ومحتاج مساعدة فورية (مشكلة صحية، فقدان مستندات، أو أي طارئ)، تواصل معنا فورًا.',
              style: AppTextStyles.body,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.call_rounded, color: AppColors.danger),
              label: const Text('اتصال طوارئ فوري', style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700)),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                side: const BorderSide(color: AppColors.danger),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
              ),
            ),
            const SizedBox(height: 10),
            PrimaryButton(label: 'مراسلة فريق الدعم', onPressed: () {}, icon: Icons.chat_bubble_outline_rounded),
          ],
        ),
      ),
    );
  }
}
