import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ServicesCenterScreen extends StatelessWidget {
  const ServicesCenterScreen({super.key});

  static const List<Map<String, dynamic>> _services = [
    {'name': 'الترجمة', 'price': '20\$', 'icon': Icons.translate_rounded},
    {'name': 'التصديق', 'price': '30\$', 'icon': Icons.verified_rounded},
    {'name': 'التأمين', 'price': '150\$', 'icon': Icons.health_and_safety_rounded},
    {'name': 'استقبال المطار', 'price': '40\$', 'icon': Icons.local_taxi_rounded},
    {'name': 'شريحة الاتصال', 'price': '10\$', 'icon': Icons.sim_card_rounded},
    {'name': 'المساعدة البنكية', 'price': '25\$', 'icon': Icons.account_balance_wallet_rounded},
    {'name': 'مساعدة الإقامة', 'price': '35\$', 'icon': Icons.badge_rounded},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مركز الخدمات',
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _services.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.05,
        ),
        itemBuilder: (context, i) {
          final s = _services[i];
          return GestureDetector(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServiceDetailScreen())),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.card), border: Border.all(color: AppColors.border)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(color: AppColors.orange.withOpacity(0.12), borderRadius: BorderRadius.circular(9)),
                    child: Icon(s['icon'] as IconData, color: AppColors.orange, size: 18),
                  ),
                  Text(s['name'] as String, style: AppTextStyles.cardTitle),
                  Text('يبدأ من ${s['price']}', style: AppTextStyles.caption),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class ServiceDetailScreen extends StatelessWidget {
  const ServiceDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'خدمة الترجمة',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ترجمة معتمدة لكل مستنداتك الرسمية من وإلى اللغة التركية والإنجليزية بمعايير مقبولة رسميًا من الجامعات.',
                style: AppTextStyles.body),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                children: const [
                  _Row(label: 'السعر', value: '20\$ للصفحة'),
                  Divider(height: 20),
                  _Row(label: 'الوقت المتوقع', value: '2-3 أيام عمل'),
                  Divider(height: 20),
                  _Row(label: 'الحالة الحالية', value: 'غير مطلوبة'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Text('المستندات المطلوبة', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(child: const Text('• نسخة أصلية أو ممسوحة ضوئيًا من المستند', style: AppTextStyles.body)),
            const SizedBox(height: 20),
            PrimaryButton(
              label: 'طلب الخدمة',
              onPressed: () => showAppConfirmDialog(
                context,
                title: 'تأكيد طلب الخدمة',
                message: 'سيتم إضافة هذه الخدمة إلى طلباتك، والدفع لاحقًا من شاشة المدفوعات. متابعة؟',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.caption),
        Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class ConsultationBookingScreen extends StatefulWidget {
  final VoidCallback? onConfirm;
  const ConsultationBookingScreen({super.key, this.onConfirm});

  @override
  State<ConsultationBookingScreen> createState() => _ConsultationBookingScreenState();
}

class _ConsultationBookingScreenState extends State<ConsultationBookingScreen> {
  int _type = 1;
  static const _types = ['مكتب', 'أونلاين', 'هاتف'];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'حجز استشارة',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('نوع الاستشارة', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            Row(
              children: List.generate(_types.length, (i) {
                final selected = i == _type;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _type = i),
                    child: Container(
                      margin: EdgeInsets.only(left: i == _types.length - 1 ? 0 : 8),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: selected ? AppColors.navy : Colors.white,
                        borderRadius: BorderRadius.circular(AppRadius.button),
                        border: Border.all(color: selected ? AppColors.navy : AppColors.border),
                      ),
                      child: Text(_types[i], style: TextStyle(color: selected ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.w600)),
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: 20),
            const Text('التاريخ والوقت', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(
              child: Row(
                children: const [
                  Icon(Icons.calendar_today_rounded, color: AppColors.navy, size: 18),
                  SizedBox(width: 10),
                  Text('اختر التاريخ والوقت المناسب', style: AppTextStyles.body),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Text('المستشار (اختياري)', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(
              child: Row(
                children: const [
                  CircleAvatar(radius: 18, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, size: 18, color: AppColors.navy)),
                  SizedBox(width: 10),
                  Text('سارة أحمد - مستشارة تعليمية', style: AppTextStyles.body),
                ],
              ),
            ),
            const Spacer(),
            PrimaryButton(
              label: 'تأكيد الموعد',
              onPressed: widget.onConfirm ??
                  () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ConsultationConfirmationScreen())),
            ),
          ],
        ),
      ),
    );
  }
}

class ConsultationConfirmationScreen extends StatelessWidget {
  const ConsultationConfirmationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'تأكيد الموعد',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(color: AppColors.success.withOpacity(0.12), shape: BoxShape.circle),
              child: const Icon(Icons.check_rounded, color: AppColors.success, size: 42),
            ),
            const SizedBox(height: 16),
            const Text('تم تأكيد موعدك بنجاح', style: AppTextStyles.cardTitle),
            const SizedBox(height: 20),
            AppCard(
              child: Column(
                children: const [
                  _Row(label: 'التاريخ والوقت', value: '18 سبتمبر - 11:00 ص'),
                  Divider(height: 20),
                  _Row(label: 'نوع الاستشارة', value: 'أونلاين'),
                  Divider(height: 20),
                  _Row(label: 'المستشار', value: 'سارة أحمد'),
                  Divider(height: 20),
                  _Row(label: 'رابط الاجتماع', value: 'meet.studybirds.com/xyz'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Text('سيتم إرسال تذكير لك قبل الموعد.', style: AppTextStyles.caption),
          ],
        ),
      ),
    );
  }
}
