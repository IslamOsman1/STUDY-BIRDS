import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class SupportCenterScreen extends StatelessWidget {
  const SupportCenterScreen({super.key});

  static const List<Map<String, dynamic>> _options = [
    {'label': 'محادثة مباشرة', 'icon': Icons.chat_bubble_outline_rounded},
    {'label': 'تذكرة دعم جديدة', 'icon': Icons.confirmation_number_outlined},
    {'label': 'طلب اتصال', 'icon': Icons.call_outlined},
    {'label': 'الأسئلة الشائعة', 'icon': Icons.help_outline_rounded},
    {'label': 'مركز المساعدة', 'icon': Icons.menu_book_outlined},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مركز الدعم',
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _options.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          final o = _options[i];
          return AppCard(
            margin: EdgeInsets.zero,
            onTap: () {},
            child: Row(
              children: [
                Icon(o['icon'] as IconData, color: AppColors.navy, size: 20),
                const SizedBox(width: 12),
                Expanded(child: Text(o['label'] as String, style: AppTextStyles.cardTitle)),
                const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
              ],
            ),
          );
        },
      ),
    );
  }
}

class NewSupportTicketScreen extends StatelessWidget {
  final VoidCallback? onSubmit;
  const NewSupportTicketScreen({super.key, this.onSubmit});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'تذكرة دعم جديدة',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('الفئة', style: AppTextStyles.caption),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.button), border: Border.all(color: AppColors.border)),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  isExpanded: true,
                  hint: const Text('اختر الفئة', style: AppTextStyles.body),
                  items: const ['المستندات', 'الدفعات', 'التأشيرة', 'أخرى']
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (_) {},
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text('الموضوع', style: AppTextStyles.caption),
            const SizedBox(height: 6),
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.button), border: Border.all(color: AppColors.border)),
              child: const TextField(
                textAlign: TextAlign.right,
                decoration: InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 12)),
              ),
            ),
            const SizedBox(height: 14),
            const Text('الرسالة', style: AppTextStyles.caption),
            const SizedBox(height: 6),
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.button), border: Border.all(color: AppColors.border)),
              child: const TextField(
                maxLines: 5,
                textAlign: TextAlign.right,
                decoration: InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.all(12)),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.attach_file_rounded, size: 18),
              label: const Text('إرفاق ملف'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 46),
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
              ),
            ),
            const SizedBox(height: 20),
            PrimaryButton(label: 'إرسال', onPressed: onSubmit),
          ],
        ),
      ),
    );
  }
}

class MyTeamScreen extends StatelessWidget {
  const MyTeamScreen({super.key});

  static const List<Map<String, String>> _team = [
    {'name': 'سارة أحمد', 'role': 'مستشارة تعليمية'},
    {'name': 'كريم منصور', 'role': 'مسؤول قبول'},
    {'name': 'لينا فوزي', 'role': 'دعم فني'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'فريقي',
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _team.length,
        itemBuilder: (context, i) {
          final m = _team[i];
          return AppCard(
            child: Row(
              children: [
                const CircleAvatar(radius: 22, backgroundColor: AppColors.border, child: Icon(Icons.person_rounded, color: AppColors.navy)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(m['name']!, style: AppTextStyles.cardTitle),
                      Text(m['role']!, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                PrimaryButton(label: 'مراسلة', onPressed: () {}, expand: false),
              ],
            ),
          );
        },
      ),
    );
  }
}

class ChatBubbleData {
  final bool isUser;
  final String text;
  final String? actionLabel;
  const ChatBubbleData({required this.isUser, required this.text, this.actionLabel});
}

class BirdAIChatScreen extends StatelessWidget {
  const BirdAIChatScreen({super.key});

  static const List<ChatBubbleData> _messages = [
    ChatBubbleData(isUser: true, text: 'شو المطلوب مني دلوقتي؟'),
    ChatBubbleData(
      isUser: false,
      text: 'إنت حاليًا في مرحلة "مراجعة الطلب" لجامعة إسطنبول التقنية. الحاجة الوحيدة المطلوبة منك هي رفع كشف الدرجات المصدق.',
      actionLabel: 'رفع مستند',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Bird AI',
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, i) {
                final m = _messages[i];
                return Align(
                  alignment: m.isUser ? Alignment.centerLeft : Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: m.isUser ? AppColors.navy : Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: m.isUser ? null : Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!m.isUser)
                          Row(
                            children: const [
                              const CircleAvatar(radius: 10, backgroundColor: Colors.white, child: Padding(padding: EdgeInsets.all(1.5), child: Image(image: AssetImage('assets/images/logo_mark.png')))),
                              SizedBox(width: 6),
                              Text('Bird AI', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.orange)),
                            ],
                          ),
                        if (!m.isUser) const SizedBox(height: 6),
                        Text(m.text, style: TextStyle(color: m.isUser ? Colors.white : AppColors.textPrimary, fontSize: 13.5)),
                        if (m.actionLabel != null) ...[
                          const SizedBox(height: 10),
                          PrimaryButton(label: m.actionLabel!, onPressed: () {}, expand: false),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30), border: Border.all(color: AppColors.border)),
              child: Row(
                children: [
                  IconButton(onPressed: () {}, icon: const Icon(Icons.send_rounded, color: AppColors.orange)),
                  const Expanded(
                    child: TextField(
                      textAlign: TextAlign.right,
                      decoration: InputDecoration(hintText: 'اكتب رسالتك...', border: InputBorder.none),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
