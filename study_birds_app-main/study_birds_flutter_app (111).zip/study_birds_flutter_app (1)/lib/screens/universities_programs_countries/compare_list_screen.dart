import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

/// Persistent "Compare" list — spec point 66: the student can keep items
/// here and return to the comparison later, separate from one-off compare views.
class CompareListScreen extends StatelessWidget {
  const CompareListScreen({super.key});

  static const List<String> _saved = ['جامعة إسطنبول التقنية', 'جامعة بهتشة شهير', 'الجامعة الأمريكية بجورجيا'];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'قائمة المقارنة',
      body: _saved.isEmpty
          ? const EmptyState(
              icon: Icons.compare_arrows_rounded,
              title: 'قائمة المقارنة فاضية',
              message: 'أضف جامعات من صفحاتها للمقارنة بينها لاحقًا.',
            )
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      itemCount: _saved.length,
                      itemBuilder: (context, i) => AppCard(
                        child: Row(
                          children: [
                            const Icon(Icons.account_balance_rounded, color: AppColors.navy, size: 20),
                            const SizedBox(width: 12),
                            Expanded(child: Text(_saved[i], style: AppTextStyles.cardTitle)),
                            IconButton(onPressed: () {}, icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  PrimaryButton(label: 'مقارنة الآن (${_saved.length})', onPressed: () {}, icon: Icons.compare_arrows_rounded),
                ],
              ),
            ),
    );
  }
}
