import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class CountriesExplorerScreen extends StatelessWidget {
  const CountriesExplorerScreen({super.key});

  static const List<Map<String, String>> _countries = [
    {'name': 'تركيا', 'unis': '180+ جامعة'},
    {'name': 'أوزبكستان', 'unis': '25 جامعة'},
    {'name': 'جورجيا', 'unis': '30 جامعة'},
    {'name': 'ماليزيا', 'unis': '45 جامعة'},
    {'name': 'كازاخستان', 'unis': '20 جامعة'},
    {'name': 'بيلاروسيا', 'unis': '15 جامعة'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'استكشاف الدول',
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _countries.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.15,
        ),
        itemBuilder: (context, i) {
          final c = _countries[i];
          return GestureDetector(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CountryDetailScreen())),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(AppRadius.card),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: AppColors.navy.withOpacity(0.08), shape: BoxShape.circle),
                  child: const Icon(Icons.public_rounded, color: AppColors.navy, size: 24),
                ),
                const SizedBox(height: 10),
                Text(c['name']!, style: AppTextStyles.cardTitle),
                const SizedBox(height: 2),
                Text(c['unis']!, style: AppTextStyles.caption),
              ],
            ),
          ),
          );
        },
      ),
    );
  }
}

class CountryDetailScreen extends StatelessWidget {
  const CountryDetailScreen({super.key});

  static const List<Map<String, dynamic>> _sections = [
    {'label': 'الجامعات', 'icon': Icons.account_balance_rounded},
    {'label': 'البرامج', 'icon': Icons.menu_book_rounded},
    {'label': 'تكاليف المعيشة', 'icon': Icons.attach_money_rounded},
    {'label': 'التأشيرة', 'icon': Icons.flight_takeoff_rounded},
    {'label': 'السكن', 'icon': Icons.home_rounded},
    {'label': 'الحياة الطلابية', 'icon': Icons.groups_rounded},
    {'label': 'إجراءات التقديم', 'icon': Icons.checklist_rounded},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'تركيا',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            height: 110,
            decoration: BoxDecoration(color: AppColors.navy.withOpacity(0.06), borderRadius: BorderRadius.circular(AppRadius.card)),
            child: const Center(child: Icon(Icons.flag_rounded, size: 40, color: AppColors.navy)),
          ),
          const SizedBox(height: 16),
          ..._sections.map(
            (s) => AppCard(
              onTap: () {},
              child: Row(
                children: [
                  Icon(s['icon'] as IconData, color: AppColors.navy, size: 20),
                  const SizedBox(width: 12),
                  Expanded(child: Text(s['label'] as String, style: AppTextStyles.cardTitle)),
                  const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: AppColors.textSecondary),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ScholarshipItem {
  final String title;
  final String type;
  final String eligibility;
  final String deadline;

  const ScholarshipItem({required this.title, required this.type, required this.eligibility, required this.deadline});
}

class ScholarshipsScreen extends StatelessWidget {
  const ScholarshipsScreen({super.key});

  static const List<ScholarshipItem> _scholarships = [
    ScholarshipItem(title: 'منحة التميز الهندسي', type: 'جزئية 50%', eligibility: 'معدل 90% فأعلى', deadline: '30 سبتمبر 2026'),
    ScholarshipItem(title: 'منحة العلوم الصحية', type: 'جزئية 30%', eligibility: 'معدل 80% فأعلى', deadline: '15 أكتوبر 2026'),
    ScholarshipItem(title: 'منحة الطلاب الدوليين الكاملة', type: 'كاملة 100%', eligibility: 'معدل 95% فأعلى + مقابلة', deadline: '1 نوفمبر 2026'),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'المنح الدراسية',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  _Chip(label: 'الدولة'),
                  SizedBox(width: 8),
                  _Chip(label: 'الدرجة العلمية'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _scholarships.length,
                itemBuilder: (context, i) {
                  final s = _scholarships[i];
                  return AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(s.title, style: AppTextStyles.cardTitle)),
                            StatusBadge(label: s.type, color: AppColors.orange),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text('الأهلية: ${s.eligibility}', style: AppTextStyles.caption),
                        Text('آخر موعد: ${s.deadline}', style: AppTextStyles.caption),
                        const SizedBox(height: 10),
                        PrimaryButton(label: 'تقديم', onPressed: () {}, expand: false),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip({required this.label});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      alignment: Alignment.center,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.chip), border: Border.all(color: AppColors.border)),
      child: Text(label, style: AppTextStyles.body.copyWith(fontSize: 12.5)),
    );
  }
}
