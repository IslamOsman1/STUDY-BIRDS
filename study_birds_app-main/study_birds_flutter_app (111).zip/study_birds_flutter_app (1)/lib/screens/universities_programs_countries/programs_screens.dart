import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ProgramsExplorerScreen extends StatelessWidget {
  const ProgramsExplorerScreen({super.key});

  static const List<String> _categories = ['الطب', 'الهندسة', 'إدارة الأعمال', 'علوم الحاسوب', 'القانون'];
  static const List<Map<String, String>> _programs = [
    {'name': 'بكالوريوس العلاج الطبيعي', 'degree': 'بكالوريوس', 'duration': '4 سنوات', 'unis': '12 جامعة'},
    {'name': 'بكالوريوس علوم الحاسوب', 'degree': 'بكالوريوس', 'duration': '4 سنوات', 'unis': '20 جامعة'},
    {'name': 'ماجستير إدارة الأعمال', 'degree': 'ماجستير', 'duration': 'سنتان', 'unis': '8 جامعات'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'استكشاف البرامج',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.card),
                border: Border.all(color: AppColors.border),
              ),
              child: const TextField(
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: 'ابحث عن برنامج...',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                  prefixIcon: Icon(Icons.search_rounded, color: AppColors.navy),
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 36,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, i) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == 0 ? AppColors.navy : Colors.white,
                    borderRadius: BorderRadius.circular(AppRadius.chip),
                    border: Border.all(color: i == 0 ? AppColors.navy : AppColors.border),
                  ),
                  child: Text(_categories[i],
                      style: TextStyle(color: i == 0 ? Colors.white : AppColors.textPrimary, fontSize: 12.5, fontWeight: FontWeight.w600)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _programs.length,
                itemBuilder: (context, i) {
                  final p = _programs[i];
                  return AppCard(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProgramDetailScreen())),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(color: AppColors.orange.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                          child: const Icon(Icons.menu_book_rounded, color: AppColors.orange, size: 19),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p['name']!, style: AppTextStyles.cardTitle),
                              Text('${p['degree']} • ${p['duration']} • ${p['unis']}', style: AppTextStyles.caption),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProgramDetailScreen extends StatelessWidget {
  const ProgramDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'بكالوريوس العلاج الطبيعي',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'برنامج معتمد يؤهل الطالب للعمل في مجال العلاج الطبيعي وإعادة التأهيل، بمزيج من الدراسة النظرية والتدريب العملي.',
              style: AppTextStyles.body,
            ),
            const SizedBox(height: 16),
            AppCard(
              child: Wrap(
                spacing: 20,
                runSpacing: 10,
                children: const [
                  _Fact(label: 'المدة', value: '4 سنوات'),
                  _Fact(label: 'اللغة', value: 'الإنجليزية'),
                  _Fact(label: 'الدرجة', value: 'بكالوريوس'),
                  _Fact(label: 'الرسوم', value: '3,500\$ - 6,000\$'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('الجامعات المتاحة', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(child: const Text('جامعة إسطنبول التقنية، جامعة بهتشة شهير، +10 أخرى', style: AppTextStyles.body)),
            const SizedBox(height: 20),
            const Text('شروط القبول', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('• شهادة الثانوية العامة بمعدل 70% فأعلى', style: AppTextStyles.body),
                  SizedBox(height: 6),
                  Text('• شهادة إتقان اللغة الإنجليزية', style: AppTextStyles.body),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('برامج ذات صلة', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            SizedBox(
              height: 90,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: 3,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (context, i) => Container(
                  width: 160,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppRadius.card),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Text('بكالوريوس التمريض', style: AppTextStyles.body),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Fact extends StatelessWidget {
  final String label;
  final String value;
  const _Fact({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.caption),
        Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class ProgramFinderScreen extends StatelessWidget {
  final VoidCallback? onSubmit;
  const ProgramFinderScreen({super.key, this.onSubmit});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مكتشف البرامج',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ساعدنا نلاقي البرنامج المناسب ليك', style: AppTextStyles.screenTitle),
            const SizedBox(height: 16),
            _finderField('المعدل الدراسي', 'مثال: 85%'),
            _finderField('المرحلة التعليمية الحالية', 'الثانوية العامة'),
            _finderChips('المواد المفضلة', ['أحياء', 'رياضيات', 'حاسوب', 'اقتصاد']),
            _finderField('الميزانية السنوية التقريبية', 'مثال: 5,000\$'),
            _finderField('الدولة المفضلة', 'تركيا'),
            _finderField('لغة الدراسة المفضلة', 'الإنجليزية'),
            const SizedBox(height: 12),
            PrimaryButton(label: 'احصل على اقتراحات', onPressed: onSubmit),
            const SizedBox(height: 10),
            const Text('النتائج استرشادية وليست قرارًا نهائيًا.', style: AppTextStyles.caption, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _finderField(String label, String hint) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppTextStyles.caption),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.button), border: Border.all(color: AppColors.border)),
            child: TextField(
              textAlign: TextAlign.right,
              decoration: InputDecoration(hintText: hint, border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _finderChips(String label, List<String> options) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppTextStyles.caption),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: options
                .map((o) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.chip), border: Border.all(color: AppColors.border)),
                      child: Text(o, style: AppTextStyles.body.copyWith(fontSize: 12.5)),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}

class ProgramFinderResultsScreen extends StatelessWidget {
  const ProgramFinderResultsScreen({super.key});

  static const List<Map<String, String>> _results = [
    {'name': 'بكالوريوس العلاج الطبيعي', 'uni': 'جامعة إسطنبول التقنية', 'meta': 'بكالوريوس • 4 سنوات'},
    {'name': 'بكالوريوس التمريض', 'uni': 'جامعة بهتشة شهير', 'meta': 'بكالوريوس • 4 سنوات'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'الاقتراحات المناسبة لك',
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _results.length,
        itemBuilder: (context, i) {
          final r = _results[i];
          return AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r['name']!, style: AppTextStyles.cardTitle),
                const SizedBox(height: 4),
                Text('${r['uni']} — ${r['meta']}', style: AppTextStyles.caption),
                const SizedBox(height: 10),
                PrimaryButton(label: 'عرض البرنامج', onPressed: () {}, expand: false),
              ],
            ),
          );
        },
      ),
    );
  }
}
