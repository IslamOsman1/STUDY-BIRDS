import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class UniversityCard {
  final String name;
  final String city;
  final String country;
  final String tuition;
  final String language;
  final bool hasScholarship;

  const UniversityCard({
    required this.name,
    required this.city,
    required this.country,
    required this.tuition,
    required this.language,
    this.hasScholarship = false,
  });
}

class _FilterChips extends StatelessWidget {
  final List<String> labels;
  const _FilterChips({required this.labels});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: labels.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadius.chip),
            border: Border.all(color: AppColors.border),
          ),
          child: Text(labels[i], style: AppTextStyles.body.copyWith(fontSize: 12.5)),
        ),
      ),
    );
  }
}

class UniversitiesExplorerScreen extends StatelessWidget {
  const UniversitiesExplorerScreen({super.key});

  static const List<UniversityCard> _list = [
    UniversityCard(name: 'جامعة إسطنبول التقنية', city: 'إسطنبول', country: 'تركيا', tuition: '3,500\$ - 6,000\$', language: 'الإنجليزية', hasScholarship: true),
    UniversityCard(name: 'جامعة بهتشة شهير', city: 'إسطنبول', country: 'تركيا', tuition: '4,000\$ - 7,500\$', language: 'الإنجليزية/التركية'),
    UniversityCard(name: 'الجامعة الأمريكية بجورجيا', city: 'تبليسي', country: 'جورجيا', tuition: '2,800\$ - 5,000\$', language: 'الإنجليزية', hasScholarship: true),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'استكشاف الجامعات',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.card),
                border: Border.all(color: AppColors.border),
              ),
              child: const TextField(
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: 'ابحث عن جامعة...',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                  prefixIcon: Icon(Icons.search_rounded, color: AppColors.navy),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const _FilterChips(labels: ['الدولة', 'المدينة', 'البرنامج', 'منحة دراسية']),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _list.length,
                itemBuilder: (context, i) {
                  final u = _list[i];
                  return AppCard(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const UniversityDetailScreen())),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: AppColors.navy.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.account_balance_rounded, color: AppColors.navy, size: 19),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(u.name, style: AppTextStyles.cardTitle),
                                  Text('${u.city}، ${u.country}', style: AppTextStyles.caption),
                                ],
                              ),
                            ),
                            if (u.hasScholarship)
                              const StatusBadge(label: 'منحة', color: AppColors.success),
                          ],
                        ),
                        const Divider(height: 18),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('الرسوم: ${u.tuition}', style: AppTextStyles.caption),
                            Text(u.language, style: AppTextStyles.caption),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class UniversityDetailScreen extends StatefulWidget {
  const UniversityDetailScreen({super.key});
  @override
  State<UniversityDetailScreen> createState() => _UniversityDetailScreenState();
}

class _UniversityDetailScreenState extends State<UniversityDetailScreen> {
  int _tab = 0;
  static const _tabs = ['البرامج', 'الرسوم', 'شروط القبول', 'المنح الدراسية', 'الحياة الطلابية'];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'جامعة إسطنبول التقنية',
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.bookmark_border_rounded, color: Colors.white)),
      ],
      body: Column(
        children: [
          Container(
            height: 130,
            width: double.infinity,
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.navy.withOpacity(0.06),
              borderRadius: BorderRadius.circular(AppRadius.card),
            ),
            child: const Center(child: Icon(Icons.account_balance_rounded, size: 44, color: AppColors.navy)),
          ),
          SizedBox(
            height: 40,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _tabs.length,
              itemBuilder: (context, i) {
                final selected = i == _tab;
                return GestureDetector(
                  onTap: () => setState(() => _tab = i),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? AppColors.navy : Colors.white,
                      borderRadius: BorderRadius.circular(AppRadius.chip),
                      border: Border.all(color: selected ? AppColors.navy : AppColors.border),
                    ),
                    child: Text(_tabs[i],
                        style: TextStyle(color: selected ? Colors.white : AppColors.textPrimary, fontSize: 12.5, fontWeight: FontWeight.w600)),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  AppCard(child: Text('محتوى تبويب "${_tabs[_tab]}" يظهر هنا.', style: AppTextStyles.body)),
                  const SizedBox(height: 8),
                  PrimaryButton(
                    label: 'مقارنة مع جامعة أخرى',
                    icon: Icons.compare_arrows_rounded,
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CompareUniversitiesScreen())),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CompareUniversitiesScreen extends StatelessWidget {
  const CompareUniversitiesScreen({super.key});

  static const List<String> _rows = ['الرسوم الدراسية', 'اللغة', 'الموقع', 'مدة الدراسة', 'منحة دراسية', 'شروط القبول'];
  static const List<Map<String, String>> _cols = [
    {'name': 'إسطنبول التقنية', 'الرسوم الدراسية': '3,500\$', 'اللغة': 'إنجليزي', 'الموقع': 'إسطنبول', 'مدة الدراسة': '4 سنوات', 'منحة دراسية': 'متاحة', 'شروط القبول': 'متوسطة'},
    {'name': 'بهتشة شهير', 'الرسوم الدراسية': '4,000\$', 'اللغة': 'إنجليزي/تركي', 'الموقع': 'إسطنبول', 'مدة الدراسة': '4 سنوات', 'منحة دراسية': 'غير متاحة', 'شروط القبول': 'مرتفعة'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'مقارنة الجامعات',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Table(
          border: TableBorder.symmetric(inside: BorderSide(color: AppColors.border)),
          columnWidths: {0: const FixedColumnWidth(90), for (var i = 1; i <= _cols.length; i++) i: const FixedColumnWidth(130)},
          children: [
            TableRow(children: [
              const SizedBox(),
              for (final c in _cols)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text(c['name']!, style: AppTextStyles.cardTitle, textAlign: TextAlign.center),
                ),
            ]),
            for (final label in _rows)
              TableRow(children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(label, style: AppTextStyles.caption),
                ),
                for (final c in _cols)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Text(c[label] ?? '-', style: AppTextStyles.body, textAlign: TextAlign.center),
                  ),
              ]),
          ],
        ),
      ),
    );
  }
}
