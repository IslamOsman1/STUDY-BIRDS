import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class AccommodationScreen extends StatelessWidget {
  const AccommodationScreen({super.key});

  static const List<Map<String, String>> _options = [
    {'name': 'سكن الطلاب - المبنى B', 'price': '250\$/شهريًا', 'distance': '5 دقائق مشيًا'},
    {'name': 'شقة مشتركة - وسط المدينة', 'price': '180\$/شهريًا', 'distance': '15 دقيقة بالباص'},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'السكن',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: _options.length,
                itemBuilder: (context, i) {
                  final o = _options[i];
                  return AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 100,
                          decoration: BoxDecoration(color: AppColors.navy.withOpacity(0.06), borderRadius: BorderRadius.circular(10)),
                          child: const Center(child: Icon(Icons.home_rounded, color: AppColors.navy, size: 32)),
                        ),
                        const SizedBox(height: 10),
                        Text(o['name']!, style: AppTextStyles.cardTitle),
                        const SizedBox(height: 4),
                        Text('${o['price']} • ${o['distance']}', style: AppTextStyles.caption),
                      ],
                    ),
                  );
                },
              ),
            ),
            PrimaryButton(label: 'طلب سكن', onPressed: () {}),
          ],
        ),
      ),
    );
  }
}

class UniversityRegistrationScreen extends StatelessWidget {
  const UniversityRegistrationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'تسجيل الجامعة',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Align(alignment: Alignment.centerRight, child: StatusBadge(label: 'بانتظار الموعد', color: AppColors.warning)),
            const SizedBox(height: 16),
            const Text('المستندات المطلوبة', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('• جواز السفر الأصلي', style: AppTextStyles.body),
                  SizedBox(height: 6),
                  Text('• خطاب القبول النهائي', style: AppTextStyles.body),
                  SizedBox(height: 6),
                  Text('• إيصال دفع الرسوم', style: AppTextStyles.body),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Text('الموعد', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(
              child: Row(
                children: const [
                  Icon(Icons.school_rounded, color: AppColors.navy),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('13 أكتوبر 2026', style: AppTextStyles.cardTitle),
                      Text('الحرم الجامعي الرئيسي', style: AppTextStyles.caption),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class InsuranceScreen extends StatelessWidget {
  const InsuranceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'التأمين الصحي',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Align(alignment: Alignment.centerRight, child: StatusBadge(label: 'ساري المفعول', color: AppColors.success)),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                children: const [
                  _KVRow(label: 'شركة التأمين', value: 'SGK Turkey'),
                  Divider(height: 20),
                  _KVRow(label: 'تغطية التأمين', value: 'شاملة (عام + طوارئ)'),
                  Divider(height: 20),
                  _KVRow(label: 'تاريخ الانتهاء', value: '10 أكتوبر 2027'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            PrimaryButton(label: 'تحميل وثيقة التأمين', onPressed: () {}, icon: Icons.download_rounded),
          ],
        ),
      ),
    );
  }
}

class _KVRow extends StatelessWidget {
  final String label;
  final String value;
  const _KVRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.caption),
        Text(value, style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class EquivalencyScreen extends StatelessWidget {
  const EquivalencyScreen({super.key});

  static const List<Map<String, dynamic>> _docs = [
    {'name': 'شهادة الثانوية المصدقة', 'uploaded': true},
    {'name': 'كشف الدرجات المترجم', 'uploaded': false},
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'معادلة الشهادة',
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PrimaryButton(label: 'طلب معادلة', onPressed: () {}, icon: Icons.assignment_rounded),
            const SizedBox(height: 16),
            const Text('المستندات المطلوبة', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            AppCard(
              child: Column(
                children: _docs
                    .map((d) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Icon(
                                d['uploaded'] as bool ? Icons.check_circle_rounded : Icons.upload_file_rounded,
                                size: 20,
                                color: d['uploaded'] as bool ? AppColors.success : AppColors.orange,
                              ),
                              const SizedBox(width: 10),
                              Expanded(child: Text(d['name'] as String, style: AppTextStyles.body)),
                            ],
                          ),
                        ))
                    .toList(),
              ),
            ),
            const SizedBox(height: 16),
            const Text('حالة الطلب', style: AppTextStyles.sectionLabel),
            const SizedBox(height: 10),
            const AppCard(child: StatusBadge(label: 'قيد المراجعة', color: AppColors.info)),
          ],
        ),
      ),
    );
  }
}
